#import <UIKit/UIKit.h>

@interface FileManagerViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong, readonly) NSString *currentPath;
@property (nonatomic, strong, readonly) UITableView *tableView;
@property (nonatomic, strong, readonly) NSMutableArray *fileList;
- (instancetype)initWithPath:(NSString *)path;
/// Zip `srcPath` into `dstPath`. Exposed so other screens (e.g. the
/// decryption view) can package an app bundle into an .ipa.
FOUNDATION_EXPORT NSString *zipPathTo(NSString *srcPath, NSString *dstPath);

@end
