#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
#import "FileManager.h"
#import "SKAppOwn.h"
#import "SKSandboxKeeper.h"
#import "darksword.h"
#import <sys/stat.h>
#import <sys/types.h>
#import <dirent.h>
#import <unistd.h>
#import <errno.h>
#import <stdlib.h>
#include <limits.h>
#include <string.h>
#include <zlib.h>
#include <time.h>
#include <utime.h>

#pragma mark - NSString category helpers

static inline const char *utf8Str(id obj) {
    return [(NSString *)obj UTF8String];
}

static inline NSString *TrimStr(NSString *s) {
    return [s stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

static inline void HapticMedium(void) {
    if (@available(iOS 10.0, *)) {
        UIImpactFeedbackGenerator *g = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleMedium];
        [g prepare];
        [g impactOccurred];
    }
}
static inline void HapticLight(void) {
    if (@available(iOS 10.0, *)) {
        UIImpactFeedbackGenerator *g = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
        [g prepare];
        [g impactOccurred];
    }
}
static inline void HapticSelect(void) {
    if (@available(iOS 10.0, *)) {
        UISelectionFeedbackGenerator *g = [[UISelectionFeedbackGenerator alloc] init];
        [g prepare];
        [g selectionChanged];
    }
}

static inline unsigned scanOctal(NSString *s) {
    unsigned val = 0;
    const char *p = s.UTF8String;
    while (*p) {
        if (*p < '0' || *p > '7') break;
        val = val * 8 + (*p - '0');
        p++;
    }
    return val;
}

#pragma mark - Global Clipboard (lara-style santanderclip)

@interface ClipboardItem : NSObject
@property (nonatomic, copy) NSString *path;
@property (nonatomic, assign) BOOL isDir;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, assign) BOOL isCut; // YES = move, NO = copy
@end
@implementation ClipboardItem
@end

static ClipboardItem *gClipboard = nil;

#pragma mark - ZIP helpers (translated from lara zipmgr.swift)

static const UInt32 zipEOCDSig  = 0x06054b50;
static const UInt32 zipCDSig    = 0x02014b50;
static const UInt32 zipLFHSig   = 0x04034b50;

static void zipWriteLE16(UInt16 val, NSMutableData *d) {
    [d appendBytes:&val length:2];
}
static void zipWriteLE32(UInt32 val, NSMutableData *d) {
    [d appendBytes:&val length:4];
}

static UInt32 zipCrc32Table[256];
static dispatch_once_t zipCrcOnce;
static void zipInitCrcTable(void) {
    dispatch_once(&zipCrcOnce, ^{
        for (UInt32 n = 0; n < 256; n++) {
            UInt32 c = n;
            for (int k = 0; k < 8; k++) {
                c = (c & 1) ? (0xedb88320 ^ (c >> 1)) : (c >> 1);
            }
            zipCrc32Table[n] = c;
        }
    });
}
static UInt32 zipCrc32(NSData *data) {
    zipInitCrcTable();
    UInt32 c = 0xffffffff;
    const UInt8 *p = (const UInt8 *)data.bytes;
    for (NSUInteger i = 0; i < data.length; i++) {
        c = zipCrc32Table[(c ^ p[i]) & 0xff] ^ (c >> 8);
    }
    return c ^ 0xffffffff;
}

static BOOL recursiveZipDir(NSString *srcDir, NSString *relativeBase,
                            NSMutableArray<NSDictionary *> *fileEntries,
                            NSMutableArray<NSString *> *dirEntries) {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSError *err = nil;
    NSArray *names = [fm contentsOfDirectoryAtPath:srcDir error:&err];
    if (!names) return NO;

    for (NSString *name in names) {
        NSString *full = [srcDir stringByAppendingPathComponent:name];
        NSString *rel = relativeBase.length ? [relativeBase stringByAppendingPathComponent:name] : name;

        BOOL isDir = NO;
        if (![fm fileExistsAtPath:full isDirectory:&isDir]) continue;

        if (isDir) {
            [dirEntries addObject:[rel stringByAppendingString:@"/"]];
            recursiveZipDir(full, rel, fileEntries, dirEntries);
        } else {
            NSData *data = [NSData dataWithContentsOfFile:full
                                                  options:NSDataReadingMappedIfSafe
                                                    error:nil];
            if (!data) data = [NSData data];
            UInt32 crc = zipCrc32(data);
            [fileEntries addObject:@{
                @"name": rel,
                @"data": data,
                @"crc": @(crc)
            }];
        }
    }
    return YES;
}

// Returns nil on success, else error message
NSString *zipPathTo(NSString *srcPath, NSString *dstPath) {
    NSFileManager *fm = [NSFileManager defaultManager];
    BOOL isDir = NO;
    if (![fm fileExistsAtPath:srcPath isDirectory:&isDir]) {
        return @"源文件不存在";
    }

    NSMutableArray<NSDictionary *> *fileEntries = [NSMutableArray array];
    NSMutableArray<NSString *> *dirEntries = [NSMutableArray array];

    if (isDir) {
        // Add the root dir entry
        NSString *rootName = srcPath.lastPathComponent;
        [dirEntries addObject:[rootName stringByAppendingString:@"/"]];
        if (!recursiveZipDir(srcPath, rootName, fileEntries, dirEntries)) {
            return @"无法枚举目录内容";
        }
    } else {
        NSData *data = [NSData dataWithContentsOfFile:srcPath
                                              options:NSDataReadingMappedIfSafe
                                                error:nil];
        if (!data) return @"无法读取文件内容";
        UInt32 crc = zipCrc32(data);
        [fileEntries addObject:@{
            @"name": srcPath.lastPathComponent,
            @"data": data,
            @"crc": @(crc)
        }];
    }

    [fm createFileAtPath:dstPath contents:nil attributes:nil];
    NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:dstPath];
    if (!fh) return @"无法创建ZIP文件";

    NSMutableArray<NSNumber *> *localOffsets = [NSMutableArray array];
    NSMutableArray<NSData *> *cdEntries = [NSMutableArray array];
    UInt16 compressionMethod = 0; // store only for compatibility

    @autoreleasepool {
        for (NSDictionary *entry in fileEntries) {
            NSString *name = entry[@"name"];
            NSData *data = entry[@"data"];
            UInt32 crc = [entry[@"crc"] unsignedIntValue];
            NSData *nameData = [name dataUsingEncoding:NSUTF8StringEncoding];
            UInt16 nameLen = (UInt16)nameData.length;
            UInt32 offset = (UInt32)fh.offsetInFile;

            NSMutableData *lfh = [NSMutableData data];
            zipWriteLE32(zipLFHSig, lfh);
            zipWriteLE16(20, lfh);          // version needed
            zipWriteLE16(0x0800, lfh);       // flags = UTF8 name
            zipWriteLE16(compressionMethod, lfh);
            zipWriteLE16(0, lfh);            // mod time
            zipWriteLE16(0, lfh);            // mod date
            zipWriteLE32(crc, lfh);
            zipWriteLE32((UInt32)data.length, lfh);
            zipWriteLE32((UInt32)data.length, lfh);
            zipWriteLE16(nameLen, lfh);
            zipWriteLE16(0, lfh);            // extra len
            [fh writeData:lfh];
            [fh writeData:nameData];
            if (data.length) [fh writeData:data];

            NSMutableData *cd = [NSMutableData data];
            zipWriteLE32(zipCDSig, cd);
            zipWriteLE16(20, cd);            // version made by
            zipWriteLE16(20, cd);            // version needed
            zipWriteLE16(0x0800, cd);        // flags = UTF8
            zipWriteLE16(compressionMethod, cd);
            zipWriteLE16(0, cd);             // mod time
            zipWriteLE16(0, cd);             // mod date
            zipWriteLE32(crc, cd);
            zipWriteLE32((UInt32)data.length, cd);
            zipWriteLE32((UInt32)data.length, cd);
            zipWriteLE16(nameLen, cd);
            zipWriteLE16(0, cd);             // extra
            zipWriteLE16(0, cd);             // comment
            zipWriteLE16(0, cd);             // disk number start
            zipWriteLE16(0, cd);             // internal attr
            // Preserve the real mode. A hardcoded 0644 stripped the executable
            // bit off binaries, which breaks sideloading an .ipa.
            {
                struct stat st;
                mode_t mode = 0100644;
                // `name` is relative to the zip root, and srcPath's parent is
                // that root — appending it to srcPath would duplicate the
                // leading folder and the stat would always fail.
                NSString *fullPath = [[srcPath stringByDeletingLastPathComponent]
                                      stringByAppendingPathComponent:name];
                if (stat(fullPath.fileSystemRepresentation, &st) == 0) {
                    mode = st.st_mode & 07777;
                    mode |= 0100000;   // S_IFREG
                }
                // External attributes: the high 16 bits hold the Unix mode,
                // the low 16 bits the DOS attributes. Getting this order wrong
                // (e.g. OR-ing the mode into the low half) produces a malformed
                // central directory that strict ZIP readers reject outright.
                zipWriteLE32(((UInt32)mode << 16), cd);
            }
            zipWriteLE32(offset, cd);
            [cd appendData:nameData];

            [localOffsets addObject:@(offset)];
            [cdEntries addObject:cd];
        }

        for (NSString *dirName in dirEntries) {
            NSData *nameData = [dirName dataUsingEncoding:NSUTF8StringEncoding];
            UInt16 nameLen = (UInt16)nameData.length;
            UInt32 offset = (UInt32)fh.offsetInFile;

            NSMutableData *lfh = [NSMutableData data];
            zipWriteLE32(zipLFHSig, lfh);
            zipWriteLE16(20, lfh);
            zipWriteLE16(0x0800, lfh);
            zipWriteLE16(0, lfh);
            zipWriteLE16(0, lfh);
            zipWriteLE16(0, lfh);
            zipWriteLE32(0, lfh);
            zipWriteLE32(0, lfh);
            zipWriteLE32(0, lfh);
            zipWriteLE16(nameLen, lfh);
            zipWriteLE16(0, lfh);
            [fh writeData:lfh];
            [fh writeData:nameData];

            NSMutableData *cd = [NSMutableData data];
            zipWriteLE32(zipCDSig, cd);
            zipWriteLE16(20, cd);
            zipWriteLE16(20, cd);
            zipWriteLE16(0x0800, cd);
            zipWriteLE16(0, cd);
            zipWriteLE16(0, cd);
            zipWriteLE16(0, cd);
            zipWriteLE32(0, cd);
            zipWriteLE32(0, cd);
            zipWriteLE32(0, cd);
            zipWriteLE16(nameLen, cd);
            zipWriteLE16(0, cd);
            zipWriteLE16(0, cd);
            zipWriteLE16(0, cd);
            zipWriteLE16(0, cd);
            zipWriteLE16(0, cd);
            zipWriteLE32(0x41ED0000, cd); // directory external attr
            zipWriteLE32(offset, cd);
            [cd appendData:nameData];
            [cdEntries addObject:cd];
        }
    }

    UInt32 cdOffset = (UInt32)fh.offsetInFile;
    UInt32 cdSize = 0;
    for (NSData *cd in cdEntries) {
        [fh writeData:cd];
        cdSize += (UInt32)cd.length;
    }

    UInt16 totalEntries = (UInt16)(fileEntries.count + dirEntries.count);
    NSMutableData *eocd = [NSMutableData data];
    zipWriteLE32(zipEOCDSig, eocd);
    zipWriteLE16(0, eocd);
    zipWriteLE16(0, eocd);
    zipWriteLE16(totalEntries, eocd);
    zipWriteLE16(totalEntries, eocd);
    zipWriteLE32(cdSize, eocd);
    zipWriteLE32(cdOffset, eocd);
    zipWriteLE16(0, eocd);
    [fh writeData:eocd];
    [fh closeFile];
    return nil;
}

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - Recovery from a failed file operation
// ─────────────────────────────────────────────────────────────────────────────
//
// Two completely unrelated problems both come back as "permission denied":
//
//   EPERM   the sandbox policy was re-derived from the on-disk profile and our
//           edit is gone. The file is fine; our permission to touch it is not.
//           Re-applying the escape restores it, without re-running the exploit.
//   EACCES  the parent directory is not ours, so it cannot be written to.
//           Fixing it means taking ownership of that directory.
//
// Reporting strerror(errno) tells the operator neither, so the operation is
// retried once after repairing both, and if it still fails the two states are
// reported separately.

// Defined below; declared here because the recovery path above it calls it.
static int recursive_delete_c(const char *path);

static int SKDeleteWithRecovery(NSString *path, BOOL isDir) {
    int r = isDir ? recursive_delete_c(utf8Str(path)) : unlink(utf8Str(path));
    if (r == 0) return 0;

    int e = errno;
    if (e != EACCES && e != EPERM) return r;

    [SKSandboxKeeper ensureWriteAccess];   // 1. re-apply the sandbox policy
    SKEnsureWriteAccess(path);             // 2. container ownership (no-op outside one)

    errno = 0;
    return isDir ? recursive_delete_c(utf8Str(path)) : unlink(utf8Str(path));
}

static NSString *SKFailureDetail(NSString *path, int err) {
    NSMutableString *m = [NSMutableString string];
    [m appendFormat:@"errno=%d (%s)\n", err, strerror(err)];

    BOOL escaped = [SKSandboxKeeper hasPrivilegedWriteAccess];
    [m appendFormat:@"sandbox_write_access=%d\n", escaped ? 1 : 0];
    [m appendFormat:@"ds_is_ready=%d\n", ds_is_ready() ? 1 : 0];

    NSString *parent = [path stringByDeletingLastPathComponent];
    struct stat psb;
    if (parent.length && lstat(utf8Str(parent), &psb) == 0) {
        [m appendFormat:@"parent=%s uid=%u gid=%u mode=%04o\n",
            utf8Str(parent), psb.st_uid, psb.st_gid, psb.st_mode & 07777];
        if (psb.st_uid != 501) {
            [m appendFormat:@"dac_deny: parent owner is not 501; unlink() requires "
                            "write on the PARENT directory\n"];
        }
    } else {
        [m appendFormat:@"lstat(%s) failed: %s\n", utf8Str(parent), strerror(errno)];
    }
    return m;
}

#pragma mark - File operations

static int recursive_delete_c(const char *path) {
    DIR *dir = opendir(path);
    if (!dir) return unlink(path);
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) continue;
        char child[PATH_MAX];
        snprintf(child, sizeof(child), "%s/%s", path, entry->d_name);
        struct stat st;
        if (lstat(child, &st) == 0) {
            if (S_ISDIR(st.st_mode)) recursive_delete_c(child);
            else unlink(child);
        }
    }
    closedir(dir);
    return rmdir(path);
}

static NSString *uniquePath(NSString *base) {
    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:base]) return base;
    NSString *dir = [base stringByDeletingLastPathComponent];
    NSString *file = base.lastPathComponent;
    NSString *ext = file.pathExtension;
    NSString *stem = ext.length ? [file stringByDeletingPathExtension] : file;
    for (int i = 1; ; i++) {
        NSString *suffix = i == 1 ? @" copy" : [NSString stringWithFormat:@" copy %d", i];
        NSString *name = ext.length ? [NSString stringWithFormat:@"%@%@.%@", stem, suffix, ext]
                                    : [NSString stringWithFormat:@"%@%@", stem, suffix];
        NSString *cand = [dir stringByAppendingPathComponent:name];
        if (![fm fileExistsAtPath:cand]) return cand;
    }
}

static BOOL clearImmutableFlag(NSString *path) {
    // Clear immutable flag on iOS 16+ for delete/chmod/chown operations
    NSFileManager *fm = [NSFileManager defaultManager];
    NSError *err = nil;
    [fm setAttributes:@{NSFileImmutable: @(NO)} ofItemAtPath:path error:&err];
    return YES; // ignore errors; some files don't expose this flag
}

static BOOL copyItem(NSString *src, NSString *dst) {
    NSFileManager *fm = [NSFileManager defaultManager];
    SKEnsureWriteAccess(dst);
    clearImmutableFlag(dst);
    NSError *err = nil;
    return [fm copyItemAtPath:src toPath:dst error:&err];
}

static BOOL moveItem(NSString *src, NSString *dst) {
    NSFileManager *fm = [NSFileManager defaultManager];
    SKEnsureWriteAccess(dst);
    clearImmutableFlag(dst);
    NSError *err = nil;
    if ([fm moveItemAtPath:src toPath:dst error:&err]) return YES;
    // Fallback to copy+delete on cross-device failure
    if (copyItem(src, dst)) {
        if (recursive_delete_c(src.UTF8String) == 0) return YES;
    }
    return NO;
}


#pragma mark - Text Editor (browse / edit / save)

@interface FMTextEditorViewController : UIViewController <UITextViewDelegate>
@property (nonatomic, copy) NSString *filePath;
@property (nonatomic, strong) UITextView *textView;
@property (nonatomic, assign) BOOL modified;
@end
@implementation FMTextEditorViewController

- (instancetype)initWithPath:(NSString *)path {
    self = [super init];
    if (self) { _filePath = [path copy]; }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor systemBackgroundColor];
    self.title = self.filePath.lastPathComponent;

    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSave
                                                                                             target:self
                                                                                             action:@selector(saveTapped)];

    // TextView
    self.textView = [[UITextView alloc] initWithFrame:CGRectZero];
    self.textView.delegate = self;
    self.textView.font = [UIFont fontWithName:@"Menlo-Regular" size:14];
    self.textView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.textView.text = @"";
    self.textView.editable = YES;
    [self.view addSubview:self.textView];

    // Load content
    NSData *data = [NSData dataWithContentsOfFile:self.filePath];
    if (data) {
        NSString *text = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        if (!text) text = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
        if (text) {
            self.textView.text = text;
            self.modified = NO;
        } else {
            self.textView.text = @"[Binary or unsupported encoding]";
            self.textView.editable = NO;
        }
    } else {
        self.textView.text = @"[Cannot read file]";
        self.textView.editable = NO;
    }
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.textView.frame = UIEdgeInsetsInsetRect(self.view.bounds, self.view.safeAreaInsets);
}

- (void)textViewDidChange:(UITextView *)textView {
    self.modified = YES;
}

- (void)saveTapped {
    if (!self.modified) return;
    NSError *err = nil;
    BOOL ok = [self.textView.text writeToFile:self.filePath atomically:YES encoding:NSUTF8StringEncoding error:&err];
    if (ok) {
        self.modified = NO;
        self.navigationItem.rightBarButtonItem.enabled = YES;
        UIAlertController *a = [UIAlertController alertControllerWithTitle:@"Saved" message:nil preferredStyle:UIAlertControllerStyleAlert];
        [a addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:a animated:YES completion:nil];
    } else {
        UIAlertController *a = [UIAlertController alertControllerWithTitle:@"Save Failed" message:err.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
        [a addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:a animated:YES completion:nil];
    }
}
@end

#pragma mark - Image Viewer (scroll + zoom)

@interface FMImageViewController : UIViewController <UIScrollViewDelegate>
@property (nonatomic, copy) NSString *filePath;
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIImageView *imageView;
@end
@implementation FMImageViewController

- (instancetype)initWithPath:(NSString *)path {
    self = [super init];
    if (self) { _filePath = [path copy]; }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    self.title = self.filePath.lastPathComponent;

    self.scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    self.scrollView.delegate = self;
    self.scrollView.minimumZoomScale = 1.0;
    self.scrollView.maximumZoomScale = 6.0;
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.showsVerticalScrollIndicator = NO;
    self.scrollView.backgroundColor = [UIColor blackColor];
    [self.view addSubview:self.scrollView];

    UIImage *img = [UIImage imageWithContentsOfFile:self.filePath];
    self.imageView = [[UIImageView alloc] initWithImage:img];
    self.imageView.contentMode = UIViewContentModeScaleAspectFit;
    [self.scrollView addSubview:self.imageView];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.scrollView.frame = self.view.bounds;
    if (self.imageView.image) {
        CGSize isize = self.imageView.image.size;
        CGSize vsize = self.view.bounds.size;
        CGFloat scale = MIN(vsize.width / isize.width, vsize.height / isize.height);
        scale = MIN(scale, 1.0);
        self.scrollView.minimumZoomScale = scale;
        self.scrollView.zoomScale = scale;
        self.imageView.frame = CGRectMake(0, 0, isize.width * scale, isize.height * scale);
        self.imageView.center = CGPointMake(vsize.width/2, vsize.height/2);
    }
}

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView {
    return self.imageView;
}
@end


#pragma mark - String category

@implementation NSString (FileManagerTrim)
@end

#pragma mark - ZIP Unzip (store + deflate)

static int mkdir_p(const char *path) {
    NSMutableArray<NSString *> *comps = [NSMutableArray array];
    NSString *p = [NSString stringWithUTF8String:path];
    while (p.length > 0 && ![p isEqualToString:@"/"]) {
        [comps insertObject:p.lastPathComponent atIndex:0];
        p = [p stringByDeletingLastPathComponent];
    }
    NSString *cur = @"";
    for (NSString *c in comps) {
        cur = [cur stringByAppendingPathComponent:c];
        if (cur.length == 0) cur = @"/";
        struct stat st;
        if (stat(cur.UTF8String, &st) != 0) {
            if (mkdir(cur.UTF8String, 0755) != 0 && errno != EEXIST) return -1;
        }
    }
    return 0;
}

static NSData *inflateData(NSData *compressed, NSUInteger uncompressedSize) {
    if (!compressed || compressed.length == 0) {
        if (uncompressedSize == 0) return [NSData data];
        return nil;
    }
    z_stream strm;
    memset(&strm, 0, sizeof(strm));
    // -15: raw deflate (no zlib header) - ZIP uses raw deflate
    int ret = inflateInit2(&strm, -MAX_WBITS);
    if (ret != Z_OK) return nil;

    NSMutableData *out = [NSMutableData dataWithLength:MAX(uncompressedSize, compressed.length * 2)];
    strm.next_in = (Bytef *)compressed.bytes;
    strm.avail_in = (unsigned)compressed.length;
    strm.next_out = (Bytef *)out.mutableBytes;
    strm.avail_out = (unsigned)out.length;

    while (1) {
        ret = inflate(&strm, Z_NO_FLUSH);
        if (ret == Z_STREAM_END) break;
        if (ret == Z_OK) {
            if (strm.avail_out == 0) {
                NSUInteger used = out.length;
                out.length = used * 2;
                strm.next_out = (Bytef *)((char *)out.mutableBytes + used);
                strm.avail_out = (unsigned)(out.length - used);
            }
            continue;
        }
        inflateEnd(&strm);
        return nil;
    }
    out.length = strm.total_out;
    inflateEnd(&strm);
    return out;
}

// Returns nil on success, else error string
static NSString *unzipFileTo(NSString *zipPath, NSString *dstDir) {
    NSData *zd = [NSData dataWithContentsOfFile:zipPath options:NSDataReadingMappedIfSafe error:nil];
    if (!zd) return @"Cannot open ZIP file";
    const UInt8 *bytes = (const UInt8 *)zd.bytes;
    NSUInteger len = zd.length;
    if (len < 22) return @"ZIP too small";

    // Find EOCD by scanning backwards
    NSInteger eocdOff = -1;
    NSInteger scanStart = (NSInteger)MAX(0, (NSInteger)len - 65557);
    for (NSInteger i = (NSInteger)len - 22; i >= scanStart; i--) {
        UInt32 sig = OSReadLittleInt32(bytes, i);
        if (sig == zipEOCDSig) { eocdOff = i; break; }
    }
    if (eocdOff < 0) return @"ZIP: no EOCD signature";
    UInt16 cdEntries = OSReadLittleInt16(bytes, eocdOff + 10);
    UInt32 cdSize = OSReadLittleInt32(bytes, eocdOff + 12);
    UInt32 cdOff = OSReadLittleInt32(bytes, eocdOff + 16);
    if (cdOff >= len || cdOff + cdSize > len) return @"ZIP: CD out of range";

    NSFileManager *fm = [NSFileManager defaultManager];
    NSError *err = nil;
    if (![fm createDirectoryAtPath:dstDir withIntermediateDirectories:YES attributes:nil error:&err]) {
        return [NSString stringWithFormat:@"mkdir failed: %@", err.localizedDescription];
    }

    NSUInteger p = cdOff;
    for (UInt16 i = 0; i < cdEntries && p + 46 <= len; i++) {
        UInt32 sig = OSReadLittleInt32(bytes, p);
        if (sig != zipCDSig) break;
        UInt16 nameLen = OSReadLittleInt16(bytes, p + 28);
        UInt16 extraLen = OSReadLittleInt16(bytes, p + 30);
        UInt16 commentLen = OSReadLittleInt16(bytes, p + 32);
        UInt16 method = OSReadLittleInt16(bytes, p + 10);
        UInt32 compSize = OSReadLittleInt32(bytes, p + 20);
        UInt32 uncompSize = OSReadLittleInt32(bytes, p + 24);
        UInt32 localHeaderOffset = OSReadLittleInt32(bytes, p + 42);
        if (p + 46 + nameLen > len) break;
        NSString *name = [[NSString alloc] initWithBytes:bytes + p + 46 length:nameLen encoding:NSUTF8StringEncoding];
        if (!name) name = [[NSString alloc] initWithBytes:bytes + p + 46 length:nameLen encoding:NSASCIIStringEncoding];
        p += 46 + nameLen + extraLen + commentLen;

        BOOL isDir = NO;
        if ([name hasSuffix:@"/"] || [name hasSuffix:@"\\"]) {
            isDir = YES;
            name = [name substringToIndex:name.length - 1];
        }
        NSString *fullDst = [dstDir stringByAppendingPathComponent:name];

        if (isDir) {
            mkdir_p(fullDst.UTF8String);
            continue;
        }
        mkdir_p([fullDst stringByDeletingLastPathComponent].UTF8String);

        // Parse local file header to get past name/extra
        if (localHeaderOffset + 30 > len) continue;
        UInt32 lfhSig = OSReadLittleInt32(bytes, localHeaderOffset);
        if (lfhSig != zipLFHSig) continue;
        UInt16 lfhNameLen = OSReadLittleInt16(bytes, localHeaderOffset + 26);
        UInt16 lfhExtraLen = OSReadLittleInt16(bytes, localHeaderOffset + 28);
        NSUInteger dataStart = localHeaderOffset + 30 + lfhNameLen + lfhExtraLen;
        if (dataStart + compSize > len) continue;

        NSData *decoded = nil;
        if (method == 0) { // stored
            decoded = [NSData dataWithBytes:bytes + dataStart length:compSize];
        } else if (method == 8) { // deflated
            NSData *comp = [NSData dataWithBytes:bytes + dataStart length:compSize];
            decoded = inflateData(comp, uncompSize);
        } else {
            continue; // unsupported compression
        }
        if (!decoded) continue;
        [decoded writeToFile:fullDst atomically:NO];
    }
    return nil;
}


#pragma mark - FileManagerViewController

@class FMTextEditorViewController;
@class FMImageViewController;

@interface FileManagerViewController () <UITableViewDelegate, UITableViewDataSource, UISearchResultsUpdating>
@property (nonatomic, strong, readwrite) NSString *currentPath;
@property (nonatomic, strong, readwrite) UITableView *tableView;
@property (nonatomic, strong, readwrite) NSMutableArray *fileList;
@property (nonatomic, strong) UILongPressGestureRecognizer *longPress;
@property (nonatomic, strong) UISearchController *searchController;
@property (nonatomic, strong) NSMutableArray *filteredList;
@property (nonatomic, assign) BOOL isSearching;
@property (nonatomic, strong) UIToolbar *toolbar;
@property (nonatomic, strong) UIView *bottomFillView;
- (void)extractZip:(NSDictionary *)item;
- (void)openFileViewerForItem:(NSDictionary *)item;
@end

@implementation FileManagerViewController

- (instancetype)initWithPath:(NSString *)path {
    self = [super init];
    if (self) {
        _currentPath = [path copy];
        _fileList = [NSMutableArray array];
        _filteredList = [NSMutableArray array];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor systemGroupedBackgroundColor];
    [self setupNavUI];
    [self setupTable];
    [self setupToolbar];
    [self setupSearch];
    [self loadDirectory];

    self.longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPress:)];
    self.longPress.minimumPressDuration = 0.4;
    [self.tableView addGestureRecognizer:self.longPress];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setToolbarHidden:NO animated:YES];
    [self updateToolbarItems];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    CGRect bounds = self.view.bounds;
    UIEdgeInsets safe = self.view.safeAreaInsets;
    CGFloat searchBarSpace = 20.0; // 搜索栏与列表分离
    CGFloat tableTop = safe.top + searchBarSpace;
    // 底栏下移10px：原上移35px -> 现上移25px
    CGFloat toolbarRaise = -12;
    CGFloat toolbarY = bounds.size.height - 44 - safe.bottom - toolbarRaise;
    // tableView底部止于toolbar顶部（toolbar下方空白单独处理）
    CGFloat tableBottom = bounds.size.height - toolbarY;

    if (@available(iOS 11.0, *)) {
        self.tableView.frame = CGRectMake(0, tableTop, bounds.size.width,
                                          bounds.size.height - tableTop - tableBottom);
        self.tableView.contentInset = UIEdgeInsetsZero;
    } else {
        self.tableView.frame = CGRectMake(0, tableTop, bounds.size.width, toolbarY - tableTop);
    }
    // Toolbar
    [self.toolbar setFrame:CGRectMake(0, toolbarY, bounds.size.width, 44)];
    // Toolbar下方一直延伸到屏幕底部，纯白填充
    if (!self.bottomFillView) {
        self.bottomFillView = [[UIView alloc] init];
        self.bottomFillView.backgroundColor = [UIColor whiteColor];
        [self.view insertSubview:self.bottomFillView belowSubview:self.toolbar];
    }
    self.bottomFillView.frame = CGRectMake(0, CGRectGetMaxY(self.toolbar.frame),
                                           bounds.size.width,
                                           bounds.size.height - CGRectGetMaxY(self.toolbar.frame));
}

#pragma mark - Setup

- (void)setupNavUI {
    self.view.backgroundColor = [UIColor systemGroupedBackgroundColor];
    self.navigationItem.title = self.currentPath;
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeNever;

    // Right: ellipsis menu (lara style - New File/Folder, Paste, Sort, etc.)
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd
                                                                              target:self
                                                                              action:@selector(addTapped)];
    self.navigationItem.rightBarButtonItem = menuBtn;

    // Left: Back if not root
    if (![self.currentPath isEqualToString:@"/var"] &&
        ![self.currentPath isEqualToString:@"/"] &&
        ![self.currentPath isEqualToString:@"/private/var"]) {
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Back"
                                                                                  style:UIBarButtonItemStylePlain
                                                                                 target:self
                                                                                 action:@selector(backTapped)];
    }
}

- (void)setupTable {
    UITableViewStyle style = UITableViewStyleInsetGrouped;
    self.tableView = [[UITableView alloc] initWithFrame:CGRectZero style:style];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.rowHeight = 60;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    self.tableView.backgroundColor = [UIColor systemGroupedBackgroundColor];
    self.tableView.separatorInset = UIEdgeInsetsMake(0, 64, 0, 0);
    if (@available(iOS 11.0, *)) {
        self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }
    [self.view addSubview:self.tableView];
}

- (void)setupSearch {
    self.searchController = [[UISearchController alloc] initWithSearchResultsController:nil];
    self.searchController.searchResultsUpdater = self;
    self.searchController.obscuresBackgroundDuringPresentation = NO;
    self.searchController.hidesNavigationBarDuringPresentation = NO;
    self.navigationItem.searchController = self.searchController;
    self.navigationItem.hidesSearchBarWhenScrolling = YES;
    self.definesPresentationContext = YES;
}

- (void)setupToolbar {
    self.toolbar = [[UIToolbar alloc] init];
    [self.view addSubview:self.toolbar];
}

- (void)updateToolbarItems {
    NSMutableArray *items = [NSMutableArray array];

    ClipboardItem *clip = gClipboard;
    UIBarButtonItem *pasteBtn;
    if (clip) {
        NSString *title = clip.isCut
            ? [NSString stringWithFormat:@"Move \"%@\" here", clip.name]
            : [NSString stringWithFormat:@"Copy \"%@\" here", clip.name];
        pasteBtn = [[UIBarButtonItem alloc] initWithTitle:title
                                                    style:UIBarButtonItemStylePlain
                                                   target:self
                                                   action:@selector(pasteHereTapped)];
    } else {
        pasteBtn = [[UIBarButtonItem alloc] initWithTitle:@"Clipboard Empty"
                                                    style:UIBarButtonItemStylePlain
                                                   target:nil
                                                   action:nil];
        pasteBtn.enabled = NO;
    }

    UIBarButtonItem *flex1 = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace
                                                                            target:nil
                                                                            action:nil];
    UIBarButtonItem *infoBtn = [[UIBarButtonItem alloc] initWithTitle:[NSString stringWithFormat:@"%lu items",
                                                                        (unsigned long)self.fileList.count]
                                                                style:UIBarButtonItemStylePlain
                                                               target:nil
                                                               action:nil];
    infoBtn.enabled = NO;
    UIBarButtonItem *flex2 = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace
                                                                            target:nil
                                                                            action:nil];
    NSString *shortPath = [self.currentPath isEqualToString:@"/var"] ? @"/var" : self.currentPath.lastPathComponent;
    UIBarButtonItem *rootBtn = [[UIBarButtonItem alloc] initWithTitle:[NSString stringWithFormat:@"%@", shortPath]
                                                                style:UIBarButtonItemStylePlain
                                                               target:self
                                                               action:@selector(goToVarRoot)];

    [items addObject:pasteBtn];
    [items addObject:flex1];
    [items addObject:infoBtn];
    [items addObject:flex2];
    [items addObject:rootBtn];
    [self.toolbar setItems:items animated:YES];
}

- (void)goToVarRoot {
    // pop to root of navigation stack (/var)
    if (self.navigationController.viewControllers.count > 1) {
        FileManagerViewController *rootVC = self.navigationController.viewControllers.firstObject;
        [self.navigationController popToViewController:rootVC animated:YES];
    }
}

#pragma mark - Directory listing

- (void)loadDirectory {
    [self.fileList removeAllObjects];

    // If we are anywhere inside an .app bundle, make that bundle's tree writable
    // first — the sandbox escape alone is not enough there because the bundle is
    // not owned by us, so open(O_WRONLY) still returns EACCES. This rewrites the
    // APFS fsnode owner the same way FilzaJailedDS does. No-op for every other
    // path, and each bundle is only done once per launch.
    SKOwnershipFixAsync(self.currentPath);

    DIR *dir = opendir(self.currentPath.UTF8String);
    if (!dir) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Error"
                                                                       message:[NSString stringWithFormat:@"Cannot open %@\n%s",
                                                                                self.currentPath, strerror(errno)]
                                                                preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }

    struct dirent *entry;
    NSMutableArray *dirs = [NSMutableArray array];
    NSMutableArray *files = [NSMutableArray array];

    while ((entry = readdir(dir)) != NULL) {
        NSString *name = [NSString stringWithUTF8String:entry->d_name];
        if ([name isEqualToString:@"."] || [name isEqualToString:@".."]) continue;

        NSString *fullPath = [self.currentPath stringByAppendingPathComponent:name];
        BOOL isDir = NO;
        struct stat st;
        memset(&st, 0, sizeof(st));
        if (lstat(fullPath.UTF8String, &st) == 0) {
            isDir = S_ISDIR(st.st_mode);
        } else if (stat(fullPath.UTF8String, &st) == 0) {
            isDir = S_ISDIR(st.st_mode);
        }

        NSDictionary *item = @{
            @"name": name,
            @"path": fullPath,
            @"isDir": @(isDir),
            @"size": @((unsigned long long)st.st_size),
            @"mode": @((unsigned int)st.st_mode),
            @"mtime": @((unsigned long)st.st_mtime),
            @"ctime": @((unsigned long)st.st_ctime),
            @"uid": @((unsigned int)st.st_uid),
            @"gid": @((unsigned int)st.st_gid),
            @"nlink": @((unsigned int)st.st_nlink)
        };

        if (isDir) [dirs addObject:item];
        else [files addObject:item];
    }
    closedir(dir);

    [dirs sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
        return [a[@"name"] caseInsensitiveCompare:b[@"name"]];
    }];
    [files sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
        return [a[@"name"] caseInsensitiveCompare:b[@"name"]];
    }];

    [self.fileList addObjectsFromArray:dirs];
    [self.fileList addObjectsFromArray:files];
    [self.tableView reloadData];
    [self updateToolbarItems];
}

#pragma mark - UISearchResultsUpdating

- (void)updateSearchResultsForSearchController:(UISearchController *)sc {
    NSString *query = TrimStr(sc.searchBar.text);
    if (query.length == 0) {
        self.isSearching = NO;
        [self.filteredList removeAllObjects];
    } else {
        self.isSearching = YES;
        [self.filteredList removeAllObjects];
        for (NSDictionary *it in self.fileList) {
            NSString *name = it[@"name"];
            NSString *path = it[@"path"];
            if ([name rangeOfString:query options:NSCaseInsensitiveSearch].location != NSNotFound ||
                [path rangeOfString:query options:NSCaseInsensitiveSearch].location != NSNotFound) {
                [self.filteredList addObject:it];
            }
        }
    }
    [self.tableView reloadData];
}

#pragma mark - TableView DataSource/Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.isSearching ? self.filteredList.count : self.fileList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *reuseId = @"FileCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseId];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:reuseId];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        cell.backgroundColor = [UIColor secondarySystemGroupedBackgroundColor];
        cell.textLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:13];
        cell.detailTextLabel.textColor = [UIColor secondaryLabelColor];
        if (@available(iOS 14.0, *)) {
            cell.backgroundConfiguration = [UIBackgroundConfiguration listSidebarCellConfiguration];
        }
    }

    NSDictionary *item = self.isSearching ? self.filteredList[indexPath.row] : self.fileList[indexPath.row];
    BOOL isDir = [item[@"isDir"] boolValue];
    NSString *name = item[@"name"];
    BOOL isHidden = [name hasPrefix:@"."];

    // SF Symbol icons (Filza-like)
    UIImage *icon = [self iconForItem:item];
    if (@available(iOS 13.0, *)) {
        UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:22 weight:UIImageSymbolWeightRegular scale:UIImageSymbolScaleMedium];
        icon = [icon imageByApplyingSymbolConfiguration:cfg] ?: icon;
    }
    cell.imageView.image = icon;
    cell.imageView.tintColor = isDir ? [UIColor systemBlueColor] : [UIColor systemGrayColor];

    cell.textLabel.text = name;
    cell.textLabel.textColor = isHidden ? [UIColor systemGrayColor] : [UIColor labelColor];

    // Subtitle: type + size/date
    if (isDir) {
        unsigned count = 0;
        NSString *dir_path = item[@"path"];
        DIR *d = opendir(dir_path.UTF8String);
        if (d) { struct dirent *e; while ((e = readdir(d)) != NULL) { if (strcmp(e->d_name, ".") && strcmp(e->d_name, "..")) count++; } closedir(d); }
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%u items  •  %@",
                                        count, [self formatDate:[item[@"mtime"] unsignedLongValue]]];
    } else {
        uint64_t size = [item[@"size"] unsignedLongLongValue];
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%@  •  %@",
                                        [self formatSize:size],
                                        [self formatDate:[item[@"mtime"] unsignedLongValue]]];
    }

    return cell;
}

- (UIImage *)iconForItem:(NSDictionary *)item API_AVAILABLE(ios(13.0)) {
    BOOL isDir = [item[@"isDir"] boolValue];
    NSString *name = item[@"name"];

    if (isDir) {
        // Blue folder icon like Filza
        return [UIImage systemImageNamed:@"folder.fill"];
    }

    NSString *ext = [[name lowercaseString] pathExtension];
    NSString *sysName = @"doc";

    // Images
    if ([@[@"png", @"jpg", @"jpeg", @"heic", @"heif", @"gif", @"webp", @"bmp", @"tif", @"tiff"] containsObject:ext]) {
        sysName = @"photo";
    }
    // Video/audio
    else if ([@[@"mp4", @"mov", @"m4v", @"avi", @"mkv"] containsObject:ext]) {
        sysName = @"play.rectangle";
    }
    else if ([@[@"mp3", @"m4a", @"aac", @"flac", @"wav", @"caf", @"opus"] containsObject:ext]) {
        sysName = @"waveform";
    }
    // Text/code/plist
    else if ([@[@"txt", @"log", @"md", @"cfg", @"conf", @"json", @"xml", @"plist", @"strings", @"yml", @"yaml", @"sh", @"m", @"mm", @"h", @"c", @"cpp", @"swift"] containsObject:ext]) {
        sysName = @"doc.text";
    }
    // Archives
    else if ([@[@"zip", @"tar", @"gz", @"tgz", @"bz2", @"xz", @"7z", @"rar", @"deb", @"ipa"] containsObject:ext]) {
        sysName = @"zipper";
        if (![UIImage systemImageNamed:sysName]) sysName = @"doc.zipper";
    }
    // Binary / dylib
    else if ([@[@"dylib", @"so", @"framework", @"bundle"] containsObject:ext]) {
        sysName = @"cpu";
    }
    // PDF
    else if ([ext isEqualToString:@"pdf"]) {
        sysName = @"doc.richtext";
    }

    UIImage *img = [UIImage systemImageNamed:sysName];
    if (!img) img = [UIImage systemImageNamed:@"doc"];
    return img;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSDictionary *item = self.isSearching ? self.filteredList[indexPath.row] : self.fileList[indexPath.row];
    if ([item[@"isDir"] boolValue]) {
        HapticSelect();
        FileManagerViewController *next = [[FileManagerViewController alloc] initWithPath:item[@"path"]];
        [self.navigationController pushViewController:next animated:YES];
    } else {
        HapticLight();
        NSString *ext = ((NSString *)item[@"name"]).pathExtension.lowercaseString;
        if ([ext isEqualToString:@"zip"]) {
            [self extractZip:item];
        } else {
            [self openFileViewerForItem:item];
        }
    }
}

#pragma mark - Long press (Filza-style action sheet)

- (void)handleLongPress:(UILongPressGestureRecognizer *)sender {
    if (sender.state != UIGestureRecognizerStateBegan) return;
    HapticMedium();
    CGPoint p = [sender locationInView:self.tableView];
    NSIndexPath *indexPath = [self.tableView indexPathForRowAtPoint:p];
    if (!indexPath) return;
    NSDictionary *item = self.isSearching ? self.filteredList[indexPath.row] : self.fileList[indexPath.row];
    [self showLongPressMenuForItem:item atIndexPath:indexPath];
}

- (void)showLongPressMenuForItem:(NSDictionary *)item atIndexPath:(NSIndexPath *)indexPath {
    BOOL isDir = [item[@"isDir"] boolValue];

    UIAlertController *menu = [UIAlertController alertControllerWithTitle:nil
                                                                   message:item[@"path"]
                                                            preferredStyle:UIAlertControllerStyleActionSheet];

    // Copy (lara-style - to app clipboard, not string)
    [menu addAction:[UIAlertAction actionWithTitle:@"Copy"
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *a) {
        ClipboardItem *ci = [[ClipboardItem alloc] init];
        ci.path = item[@"path"];
        ci.isDir = isDir;
        ci.name = item[@"name"];
        ci.isCut = NO;
        gClipboard = ci;
        HapticSelect();
        [self updateToolbarItems];
        [self toast:@"Copied to clipboard"];
    }]];

    // Cut (Move)
    [menu addAction:[UIAlertAction actionWithTitle:@"Cut / Move"
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *a) {
        ClipboardItem *ci = [[ClipboardItem alloc] init];
        ci.path = item[@"path"];
        ci.isDir = isDir;
        ci.name = item[@"name"];
        ci.isCut = YES;
        gClipboard = ci;
        HapticSelect();
        [self updateToolbarItems];
        [self toast:@"Cut - paste to move"];
    }]];

    // Rename
    [menu addAction:[UIAlertAction actionWithTitle:@"Rename"
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *a) {
        [self showRenameDialogForItem:item];
    }]];

    // Compress ZIP (files AND directories)
    [menu addAction:[UIAlertAction actionWithTitle:@"Compress to ZIP"
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *a) {
        HapticLight();
        [self compressToZip:item];
    }]];

    // Extract ZIP (if .zip extension)
    NSString *ext = ((NSString *)item[@"name"]).pathExtension.lowercaseString;
    if (!isDir && [ext isEqualToString:@"zip"]) {
        [menu addAction:[UIAlertAction actionWithTitle:@"Extract ZIP"
                                                  style:UIAlertActionStyleDefault
                                                handler:^(UIAlertAction *a) {
            HapticLight();
            [self extractZip:item];
        }]];
    }

    // Chmod (permissions)
    [menu addAction:[UIAlertAction actionWithTitle:@"Permissions (chmod)"
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *a) {
        [self showChmodSheet:item];
    }]];

    // Chown (owner/group) — the ordinary syscall. As uid 501 this always fails,
    // because vnode_authorize(KAUTH_VNODE_CHANGE_OWNER) requires uid 0. Kept
    // because it is the right tool once root is actually available.
    [menu addAction:[UIAlertAction actionWithTitle:@"Owner / Group (chown)"
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *a) {
        [self showChownSheet:item];
    }]];

    // Properties (editable)
    [menu addAction:[UIAlertAction actionWithTitle:@"Properties"
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *a) {
        [self showPropertiesForItem:item];
    }]];

    // Delete
    [menu addAction:[UIAlertAction actionWithTitle:@"Delete"
                                              style:UIAlertActionStyleDestructive
                                            handler:^(UIAlertAction *a) {
        [self showDeleteConfirmForItem:item];
    }]];

    // Cancel
    [menu addAction:[UIAlertAction actionWithTitle:@"Cancel"
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];

    UIPopoverPresentationController *pop = menu.popoverPresentationController;
    if (pop) {
        UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
        pop.sourceView = cell;
        pop.sourceRect = cell.bounds;
    }
    [self presentViewController:menu animated:YES completion:nil];
}

#pragma mark - Clipboard Paste Here

- (void)pasteHereTapped {
    ClipboardItem *ci = gClipboard;
    if (!ci) return;

    NSString *dest = [self.currentPath stringByAppendingPathComponent:ci.name];
    if ([ci.path isEqualToString:dest]) {
        [self toast:@"Same location, nothing to do"];
        return;
    }
    if (ci.isDir && ([dest hasPrefix:[ci.path stringByAppendingString:@"/"]] || [dest isEqualToString:ci.path])) {
        [self toast:@"Cannot paste folder into itself"];
        return;
    }

    // Avoid overwriting existing item (lara style - append "copy")
    NSString *finalDest = uniquePath(dest);

    BOOL ok;
    if (ci.isCut) {
        ok = moveItem(ci.path, finalDest);
        if (ok) gClipboard = nil; // clear clipboard after successful move
    } else {
        ok = copyItem(ci.path, finalDest);
        // copy keeps clipboard
    }

    if (ok) {
        [self toast:ci.isCut ? @"Moved" : @"Copied"];
        [self loadDirectory];
    } else {
        [self showAlertTitle:@"Operation Failed" msg:[NSString stringWithFormat:@"%s", strerror(errno)]];
    }
}

#pragma mark - Rename / Delete dialogs

- (void)showRenameDialogForItem:(NSDictionary *)item {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Rename" message:nil
                                                             preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *tf) {
        tf.text = item[@"name"];
        tf.autocapitalizationType = UITextAutocapitalizationTypeNone;
    }];
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Rename" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        NSString *newName = TrimStr(alert.textFields.firstObject.text);
        if (newName.length == 0 || [newName containsString:@"/"]) {
            [self showAlertTitle:@"Invalid name" msg:nil];
            return;
        }
        NSString *newPath = [[item[@"path"] stringByDeletingLastPathComponent] stringByAppendingPathComponent:newName];
        if ([newPath isEqualToString:item[@"path"]]) return;
        SKEnsureWriteAccess(item[@"path"]);
        clearImmutableFlag(item[@"path"]);
        if (rename(utf8Str(item[@"path"]), newPath.UTF8String) == 0) {
            [self loadDirectory];
        } else {
            [self showAlertTitle:@"Rename failed" msg:[NSString stringWithFormat:@"%s", strerror(errno)]];
        }
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)showDeleteConfirmForItem:(NSDictionary *)item {
    NSString *msg = [NSString stringWithFormat:@"Delete \"%@\" permanently?", item[@"name"]];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Confirm Delete"
                                                                   message:msg
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Delete" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *a) {
        BOOL isDir = [item[@"isDir"] boolValue];
        SKEnsureWriteAccess(item[@"path"]);
        clearImmutableFlag(item[@"path"]);
        int r = SKDeleteWithRecovery(item[@"path"], isDir);
        if (r == 0) {
            [self loadDirectory];
        } else {
            int err = errno;
            [self showAlertTitle:@"Delete failed" msg:SKFailureDetail(item[@"path"], err)];
        }
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - ZIP compression (files AND directories)

- (void)compressToZip:(NSDictionary *)item {
    NSString *srcPath = item[@"path"];
    NSString *zipName = [srcPath.lastPathComponent stringByAppendingString:@".zip"];
    NSString *zipPath = [self.currentPath stringByAppendingPathComponent:zipName];
    NSString *finalZip = uniquePath(zipPath);

    [self toast:@"Compressing..." duration:0.5];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *err = zipPathTo(srcPath, finalZip);
        dispatch_async(dispatch_get_main_queue(), ^{
            if (!err) {
                [self toast:@"Compressed successfully"];
                [self loadDirectory];
            } else {
                [self showAlertTitle:@"Compress failed" msg:err];
            }
        });
    });
}

#pragma mark - Chmod sheet (editable permissions)

- (void)showChmodSheet:(NSDictionary *)item {
    struct stat st;
    if (stat(utf8Str(item[@"path"]), &st) != 0) {
        [self showAlertTitle:@"Stat failed" msg:[NSString stringWithFormat:@"%s", strerror(errno)]];
        return;
    }
    unsigned currentMode = st.st_mode & 07777;

    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:@"Permissions (chmod)"
                                                                   message:item[@"path"]
                                                            preferredStyle:UIAlertControllerStyleAlert];
    NSString *placeholder = [NSString stringWithFormat:@"%04o (e.g. 0755)", currentMode];
    [sheet addTextFieldWithConfigurationHandler:^(UITextField *tf) {
        tf.placeholder = placeholder;
        tf.text = [NSString stringWithFormat:@"%04o", currentMode];
        tf.keyboardType = UIKeyboardTypeNumberPad;
    }];
    [sheet addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"Apply" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        NSString *val = TrimStr(sheet.textFields.firstObject.text);
        unsigned mode = scanOctal(val);
        if (val.length == 0 || mode > 07777) {
            [self showAlertTitle:@"Invalid mode" msg:@"Enter octal like 0755, 0644"];
            return;
        }
        clearImmutableFlag(item[@"path"]);
        if (chmod(utf8Str(item[@"path"]), (mode_t)mode) == 0) {
            [self toast:@"Permissions updated"];
            [self loadDirectory];
        } else {
            [self showAlertTitle:@"chmod failed" msg:[NSString stringWithFormat:@"%s", strerror(errno)]];
        }
    }]];
    [self presentViewController:sheet animated:YES completion:nil];
}

#pragma mark - Chown sheet (editable uid/gid)

- (void)showChownSheet:(NSDictionary *)item {
    struct stat st;
    if (stat(utf8Str(item[@"path"]), &st) != 0) {
        [self showAlertTitle:@"Stat failed" msg:[NSString stringWithFormat:@"%s", strerror(errno)]];
        return;
    }

    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:@"Owner / Group (chown)"
                                                                   message:item[@"path"]
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [sheet addTextFieldWithConfigurationHandler:^(UITextField *tf) {
        tf.placeholder = [NSString stringWithFormat:@"Owner UID (current: %d)", st.st_uid];
        tf.text = [NSString stringWithFormat:@"%d", st.st_uid];
        tf.keyboardType = UIKeyboardTypeNumberPad;
    }];
    [sheet addTextFieldWithConfigurationHandler:^(UITextField *tf) {
        tf.placeholder = [NSString stringWithFormat:@"Group GID (current: %d)", st.st_gid];
        tf.text = [NSString stringWithFormat:@"%d", st.st_gid];
        tf.keyboardType = UIKeyboardTypeNumberPad;
    }];
    [sheet addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"Apply" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        int uid = st.st_uid, gid = st.st_gid;
        NSString *u = TrimStr(sheet.textFields[0].text);
        NSString *g = TrimStr(sheet.textFields[1].text);
        if (u.length) uid = u.intValue;
        if (g.length) gid = g.intValue;
        clearImmutableFlag(item[@"path"]);
        if (chown(utf8Str(item[@"path"]), (uid_t)uid, (gid_t)gid) == 0) {
            [self toast:@"Owner updated"];
            [self loadDirectory];
        } else {
            [self showAlertTitle:@"chown failed" msg:[NSString stringWithFormat:@"%s", strerror(errno)]];
        }
    }]];
    [self presentViewController:sheet animated:YES completion:nil];
}

#pragma mark - Properties (with editable fields)


- (void)showPropertiesForItem:(NSDictionary *)item {
    struct stat st;
    memset(&st, 0, sizeof(st));
    stat(utf8Str(item[@"path"]), &st);

    NSString *kind = [item[@"isDir"] boolValue] ? @"Directory" : @"File";
    uint64_t size = [item[@"size"] unsignedLongLongValue];
    NSString *sizeStr = [item[@"isDir"] boolValue] ? @"—" : [self formatSize:size];
    NSString *modeStr = [NSString stringWithFormat:@"%04o", st.st_mode & 07777];

    NSMutableString *info = [NSMutableString string];
    [info appendFormat:@"Name:       %@\n", item[@"name"]];
    [info appendFormat:@"Path:       %@\n", item[@"path"]];
    [info appendFormat:@"Kind:       %@\n", kind];
    [info appendFormat:@"Size:       %@\n", sizeStr];
    [info appendFormat:@"Perms:      %@\n", modeStr];
    [info appendFormat:@"Owner UID:  %d\n", st.st_uid];
    [info appendFormat:@"Group GID:  %d\n", st.st_gid];
    [info appendFormat:@"Links:      %d\n", st.st_nlink];
    [info appendFormat:@"Modified:   %@\n", [self formatDate:[item[@"mtime"] unsignedLongValue]]];
    [info appendFormat:@"Changed:    %@", [self formatDate:[item[@"ctime"] unsignedLongValue]]];

    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Properties"
                                                                   message:info
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"Chmod" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        [self showChmodSheet:item];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Chown" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        [self showChownSheet:item];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Close" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - Add menu (right bar button, lara-style)

- (void)addTapped {
    UIAlertController *menu = [UIAlertController alertControllerWithTitle:nil
                                                                   message:self.currentPath
                                                            preferredStyle:UIAlertControllerStyleActionSheet];

    [menu addAction:[UIAlertAction actionWithTitle:@"Create File"
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *a) {
        [self promptForName:@"file"];
    }]];

    [menu addAction:[UIAlertAction actionWithTitle:@"New Folder"
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *a) {
        [self promptForName:@"folder"];
    }]];

    if (gClipboard) {
        [menu addAction:[UIAlertAction actionWithTitle:
                            [NSString stringWithFormat:@"Paste \"%@\" here", gClipboard.name]
                                                  style:UIAlertActionStyleDefault
                                                handler:^(UIAlertAction *a) {
            [self pasteHereTapped];
        }]];
    }

    [menu addAction:[UIAlertAction actionWithTitle:@"Jump to /var"
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *a) {
        [self goToVarRoot];
    }]];

    [menu addAction:[UIAlertAction actionWithTitle:@"Refresh"
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *a) {
        [self loadDirectory];
    }]];

    [menu addAction:[UIAlertAction actionWithTitle:@"Cancel"
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];

    UIPopoverPresentationController *pop = menu.popoverPresentationController;
    if (pop) {
        pop.barButtonItem = self.navigationItem.rightBarButtonItem;
    }
    [self presentViewController:menu animated:YES completion:nil];
}

- (void)promptForName:(NSString *)type {
    NSString *title = [type isEqualToString:@"folder"] ? @"New Folder" : @"Create File";
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:nil
                                                             preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *tf) {
        tf.placeholder = @"Enter name";
        tf.autocapitalizationType = UITextAutocapitalizationTypeNone;
    }];
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Create" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        NSString *name = TrimStr(alert.textFields.firstObject.text);
        if (name.length == 0 || [name containsString:@"/"]) {
            [self showAlertTitle:@"Invalid name" msg:nil];
            return;
        }
        NSString *newPath = [self.currentPath stringByAppendingPathComponent:name];
        NSFileManager *fm = [NSFileManager defaultManager];
        if ([fm fileExistsAtPath:newPath]) {
            [self showAlertTitle:@"Already exists" msg:nil];
            return;
        }
        NSError *err = nil;
        BOOL ok;
        // Make sure ownership is already ours before the very first write, so it
        // cannot race the background pass kicked off by loadDirectory.
        SKEnsureWriteAccess(newPath);
        if ([type isEqualToString:@"folder"]) {
            ok = [fm createDirectoryAtPath:newPath withIntermediateDirectories:NO attributes:nil error:&err];
        } else {
            ok = [fm createFileAtPath:newPath contents:nil attributes:nil];
        }
        if (ok) [self loadDirectory];
        else [self showAlertTitle:@"Create failed" msg:err.localizedDescription ?: @"—"];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - Helpers

- (void)backTapped {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)toast:(NSString *)msg {
    [self toast:msg duration:1.2];
}

- (void)toast:(NSString *)msg duration:(NSTimeInterval)dur {
    UIAlertController *toast = [UIAlertController alertControllerWithTitle:nil message:msg
                                                             preferredStyle:UIAlertControllerStyleAlert];
    [self presentViewController:toast animated:YES completion:nil];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(dur * NSEC_PER_MSEC)),
                   dispatch_get_main_queue(), ^{
        [toast dismissViewControllerAnimated:YES completion:nil];
    });
}

- (void)showAlertTitle:(NSString *)title msg:(NSString *)msg {
    UIAlertController *a = [UIAlertController alertControllerWithTitle:title
                                                               message:msg
                                                        preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:a animated:YES completion:nil];
}

- (NSString *)formatSize:(uint64_t)size {
    if (size < 1024) return [NSString stringWithFormat:@"%llu B", size];
    if (size < 1024*1024) return [NSString stringWithFormat:@"%.1f KB", size/1024.0];
    if (size < 1024ULL*1024*1024) return [NSString stringWithFormat:@"%.1f MB", size/(1024.0*1024.0)];
    return [NSString stringWithFormat:@"%.2f GB", size/(1024.0*1024.0*1024.0)];
}

- (NSString *)formatDate:(unsigned long)ts {
    NSDate *d = [NSDate dateWithTimeIntervalSince1970:ts];
    static NSDateFormatter *fmt;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        fmt = [[NSDateFormatter alloc] init];
        fmt.dateStyle = NSDateFormatterShortStyle;
        fmt.timeStyle = NSDateFormatterShortStyle;
    });
    return [fmt stringFromDate:d];
}

#pragma mark - Extract ZIP

- (void)extractZip:(NSDictionary *)item {
    NSString *zipPath = item[@"path"];
    NSString *folderName = [zipPath.lastPathComponent stringByDeletingPathExtension];
    NSString *dstDir = [[zipPath stringByDeletingLastPathComponent] stringByAppendingPathComponent:folderName];
    NSFileManager *fm = [NSFileManager defaultManager];
    BOOL isDir = NO;
    unsigned tries = 0;
    NSString *finalDst = dstDir;
    while ([fm fileExistsAtPath:finalDst isDirectory:&isDir]) {
        tries++;
        finalDst = [dstDir stringByAppendingFormat:@"-%u", tries];
    }
    NSString *err = unzipFileTo(zipPath, finalDst);
    if (err) {
        [self showAlertTitle:@"Extract failed" msg:err];
    } else {
        [self toast:@"Extracted"];
        [self loadDirectory];
    }
}

#pragma mark - File Viewer Routing

static NSSet<NSString *> *TextExts(void) {
    static NSSet *s; static dispatch_once_t once;
    dispatch_once(&once, ^{
        s = [NSSet setWithArray:@[@"txt",@"text",@"log",@"json",@"xml",@"plist",@"md",@"markdown",
                                  @"cfg",@"conf",@"ini",@"cnf",@"csv",@"tsv",@"tab",
                                  @"sh",@"bash",@"zsh",@"py",@"rb",@"pl",@"php",@"js",@"ts",
                                  @"css",@"scss",@"html",@"htm",@"xhtml",
                                  @"m",@"h",@"mm",@"c",@"cc",@"cpp",@"cxx",@"hpp",@"swift",
                                  @"java",@"kt",@"scala",@"go",@"rs",@"sql",@"yaml",@"yml",
                                  @"makefile",@"cmake",@"cmakein",@"am",@"ac",@"m4",
                                  @"dockerfile",@"env",@"gitignore",@"gitconfig",
                                  @"plist",@"strings",@"entitlements",@"lproj",@"nib",@"storyboard"]];
    });
    return s;
}

static NSSet<NSString *> *ImageExts(void) {
    static NSSet *s; static dispatch_once_t once;
    dispatch_once(&once, ^{
        s = [NSSet setWithArray:@[@"png",@"jpg",@"jpeg",@"gif",@"bmp",@"tiff",@"tif",@"heic",@"heif",
                                  @"webp",@"ico",@"cur",@"pdf"]];
    });
    return s;
}

static NSSet<NSString *> *MediaExts(void) {
    static NSSet *s; static dispatch_once_t once;
    dispatch_once(&once, ^{
        s = [NSSet setWithArray:@[@"mp4",@"mov",@"m4v",@"3gp",@"avi",
                                  @"mp3",@"m4a",@"aac",@"caf",@"wav",@"aiff",@"aif",
                                  @"flac",@"alac",@"wma",@"ogg",@"opus"]];
    });
    return s;
}

- (void)openFileViewerForItem:(NSDictionary *)item {
    NSString *path = item[@"path"];
    NSString *ext = ((NSString *)item[@"name"]).pathExtension.lowercaseString;
    if ([ImageExts() containsObject:ext]) {
        FMImageViewController *vc = [[FMImageViewController alloc] initWithPath:path];
        [self.navigationController pushViewController:vc animated:YES];
    } else if ([MediaExts() containsObject:ext]) {
        NSURL *url = [NSURL fileURLWithPath:path];
        AVPlayer *player = [AVPlayer playerWithURL:url];
        AVPlayerViewController *pvc = [[AVPlayerViewController alloc] init];
        pvc.player = player;
        [player play];
        [self presentViewController:pvc animated:YES completion:nil];
    } else {
        // Text viewer: text extensions, or unknown < 3MB
        unsigned long long size = [item[@"size"] unsignedLongLongValue];
        BOOL looksText = [TextExts() containsObject:ext] || size <= (3 * 1024 * 1024);
        if (looksText) {
            FMTextEditorViewController *vc = [[FMTextEditorViewController alloc] initWithPath:path];
            [self.navigationController pushViewController:vc animated:YES];
        } else {
            [self showPropertiesForItem:item];
        }
    }
}

@end

