//
//  SKAppBrowser.m
//  SandboxKit — installed-app browser
//

#import "SKAppBrowser.h"
#import "SKLoc.h"
#import "SKDecryptUI.h"
#import "FileManager.h"
#import "SKOverlay.h"
#import "SKLog.h"
#import "kexploit/utils.h"

#include <sys/stat.h>

static NSString * const kBundleRoot       = @"/var/containers/Bundle/Application";
static NSString * const kDataRoot         = @"/var/mobile/Containers/Data/Application";
static NSString * const kAppGroupRoot     = @"/var/mobile/Containers/Shared/AppGroup";
static NSString * const kMetadataFile     = @".com.apple.mobile_container_manager.metadata.plist";

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - Model
// ─────────────────────────────────────────────────────────────────────────────

@interface SKInstalledApp : NSObject
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *bundleID;
@property (nonatomic, copy) NSString *bundlePath;
@property (nonatomic, copy) NSString *executable;
@property (nonatomic, copy, nullable) NSString *dataPath;
@property (nonatomic, copy, nullable) NSString *groupPath;
@end

@implementation SKInstalledApp
@end

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - Icon helper
// ─────────────────────────────────────────────────────────────────────────────

// A neutral placeholder so rows never collapse when an app ships no icon we
// can read. Drawn rather than loaded, so there is no asset dependency.
static UIImage *SKPlaceholderIcon(CGFloat side) {
    UIGraphicsImageRenderer *r =
        [[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(side, side)];
    return [r imageWithActions:^(UIGraphicsImageRendererContext *ctx) {
        CGRect b = CGRectMake(0, 0, side, side);
        [[UIColor colorWithWhite:0.78 alpha:1.0] setFill];
        [[UIBezierPath bezierPathWithRoundedRect:b cornerRadius:side * 0.225] fill];

        // Faint grid, echoing the system's generic app icon.
        [[UIColor colorWithWhite:0.62 alpha:1.0] setStroke];
        UIBezierPath *p = [UIBezierPath bezierPath];
        p.lineWidth = 1.0;
        for (int i = 1; i < 3; i++) {
            CGFloat f = side * (CGFloat)i / 3.0;
            [p moveToPoint:CGPointMake(f, side * 0.16)];
            [p addLineToPoint:CGPointMake(f, side * 0.84)];
            [p moveToPoint:CGPointMake(side * 0.16, f)];
            [p addLineToPoint:CGPointMake(side * 0.84, f)];
        }
        [p stroke];
    }];
}

static UIImage *SKIconForApp(NSString *bundlePath, NSDictionary *info, CGFloat side) {
    // Preferred: the modern named-icon keys.
    NSArray *names = info[@"CFBundleIcons"][@"CFBundlePrimaryIcon"][@"CFBundleIconFiles"];
    if (![names isKindOfClass:NSArray.class]) {
        names = info[@"CFBundleIconFiles"];
    }

    NSMutableArray<NSString *> *candidates = [NSMutableArray array];
    for (NSString *n in names) {
        if (![n isKindOfClass:NSString.class]) continue;
        [candidates addObject:n];
        // The plain name usually has no extension on disk; try the @2x/@3x forms.
        [candidates addObject:[n stringByAppendingString:@"@2x"]];
        [candidates addObject:[n stringByAppendingString:@"@3x"]];
    }
    // Classic fallbacks.
    [candidates addObjectsFromArray:@[ @"AppIcon60x60@2x", @"AppIcon60x60@3x",
                                       @"Icon", @"Icon@2x", @"Icon-60@2x" ]];

    for (NSString *c in candidates) {
        for (NSString *ext in @[ @"", @".png" ]) {
            NSString *p = [bundlePath stringByAppendingPathComponent:
                           [c stringByAppendingString:ext]];
            UIImage *img = [UIImage imageWithContentsOfFile:p];
            if (img) return img;
        }
    }
    return SKPlaceholderIcon(side);
}

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - Browser
// ─────────────────────────────────────────────────────────────────────────────

@interface SKAppBrowserViewController () <UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UISearchBar *searchBar;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@property (nonatomic, strong) NSArray<SKInstalledApp *> *apps;
@property (nonatomic, strong) NSArray<SKInstalledApp *> *filtered;

// Injected SpringBoard overlay.
@property (nonatomic, strong) NSTimer *overlayTimer;
@property (nonatomic, strong) NSArray<NSDictionary *> *overlayProcs;
@property (nonatomic, assign) BOOL overlayPollBusy;
@end

@implementation SKAppBrowserViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = SKLoc(@"apps.title");
    self.view.backgroundColor = UIColor.systemGroupedBackgroundColor;

    self.searchBar = [[UISearchBar alloc] init];
    self.searchBar.delegate = (id)self;
    self.searchBar.placeholder = SKLoc(@"apps.search");
    self.searchBar.searchBarStyle = UISearchBarStyleMinimal;
    self.searchBar.autocapitalizationType = UITextAutocapitalizationTypeNone;
    [self.view addSubview:self.searchBar];

    self.tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleInsetGrouped];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.rowHeight = 64;
    self.tableView.backgroundColor = UIColor.systemGroupedBackgroundColor;
    [self.view addSubview:self.tableView];

    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleLarge];
    self.spinner.hidesWhenStopped = YES;
    [self.view addSubview:self.spinner];

    UIBarButtonItem *refresh =
        [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh
                                                      target:self action:@selector(reload)];
    // The RemoteCall floating-ball entry point is deliberately not exposed.
    // RemoteCall needs an arm64e launch context, and every arm64e build we
    // shipped has failed to load on device; leaving a button that can only ever
    // produce an error is worse than not having it. The SKOverlay implementation
    // is still here and can be re-enabled by putting the item back:
    //
    //   UIBarButtonItem *ball =
    //       [[UIBarButtonItem alloc] initWithTitle:SKLoc(@"overlay.title")
    //                                       style:UIBarButtonItemStylePlain
    //                                      target:self action:@selector(toggleOverlay)];
    //   self.navigationItem.rightBarButtonItems = @[ refresh, ball ];
    self.navigationItem.rightBarButtonItems = @[ refresh ];
    [self reload];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    CGFloat w = self.view.bounds.size.width, h = self.view.bounds.size.height;
    CGFloat top = self.view.safeAreaInsets.top, bot = self.view.safeAreaInsets.bottom;
    self.searchBar.frame = CGRectMake(0, top, w, 50);
    self.tableView.frame = CGRectMake(0, top + 50, w, h - top - 50 - bot);
    self.spinner.center = CGPointMake(w / 2, h / 2);
}

- (void)reload {
    [self.spinner startAnimating];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        NSArray *apps = [self scan];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.apps = apps;
            self.filtered = apps;
            [self.tableView reloadData];
            [self.spinner stopAnimating];
        });
    });
}

// ── container lookup ───────────────────────────────────────────────────────
static NSString *containerForIdentifier(NSString *root, NSString *identifier) {
    NSFileManager *fm = NSFileManager.defaultManager;
    for (NSString *uuid in [fm contentsOfDirectoryAtPath:root error:NULL]) {
        NSString *meta = [[root stringByAppendingPathComponent:uuid]
                          stringByAppendingPathComponent:kMetadataFile];
        NSDictionary *d = [NSDictionary dictionaryWithContentsOfFile:meta];
        if ([d[@"MCMMetadataIdentifier"] isEqualToString:identifier]) {
            return [root stringByAppendingPathComponent:uuid];
        }
    }
    return nil;
}

- (NSArray<SKInstalledApp *> *)scan {
    NSFileManager *fm = NSFileManager.defaultManager;
    NSMutableArray *out = [NSMutableArray array];
    NSString *selfID = NSBundle.mainBundle.bundleIdentifier;

    for (NSString *uuid in [fm contentsOfDirectoryAtPath:kBundleRoot error:NULL]) {
        @autoreleasepool {
            NSString *dir = [kBundleRoot stringByAppendingPathComponent:uuid];
            for (NSString *bn in [fm contentsOfDirectoryAtPath:dir error:NULL]) {
                if (![bn hasSuffix:@".app"]) continue;
                NSString *bp = [dir stringByAppendingPathComponent:bn];
                NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:
                                      [bp stringByAppendingPathComponent:@"Info.plist"]];
                NSString *bid  = info[@"CFBundleIdentifier"];
                NSString *exec = info[@"CFBundleExecutable"];
                if (!bid.length || !exec.length) continue;
                if (selfID && [bid isEqualToString:selfID]) continue;

                SKInstalledApp *a = [SKInstalledApp new];
                a.bundleID   = bid;
                a.bundlePath = bp;
                a.executable = exec;
                a.name       = info[@"CFBundleDisplayName"] ?: info[@"CFBundleName"] ?: bn;
                a.dataPath   = containerForIdentifier(kDataRoot, bid);
                a.groupPath  = containerForIdentifier(kAppGroupRoot,
                                                      [@"group." stringByAppendingString:bid]);
                [out addObject:a];
            }
        }
    }
    [out sortUsingComparator:^NSComparisonResult(SKInstalledApp *x, SKInstalledApp *y) {
        return [x.name caseInsensitiveCompare:y.name];
    }];
    return out;
}

// ── table ──────────────────────────────────────────────────────────────────
- (NSInteger)tableView:(UITableView *)tv numberOfRowsInSection:(NSInteger)s { return self.filtered.count; }

- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)ip {
    static NSString *cid = @"app";
    UITableViewCell *c = [tv dequeueReusableCellWithIdentifier:cid];
    if (!c) c = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cid];

    SKInstalledApp *a = self.filtered[ip.row];
    c.textLabel.text = a.name;
    c.textLabel.font = [UIFont monospacedSystemFontOfSize:14 weight:UIFontWeightSemibold];
    c.detailTextLabel.text = a.bundleID;
    c.detailTextLabel.textColor = UIColor.secondaryLabelColor;
    c.detailTextLabel.font = [UIFont monospacedSystemFontOfSize:10 weight:UIFontWeightRegular];
    c.accessoryType = UITableViewCellAccessoryDisclosureIndicator;

    CGFloat side = 40;
    UIImage *icon = SKIconForApp(a.bundlePath, [NSDictionary dictionaryWithContentsOfFile:
                           [a.bundlePath stringByAppendingPathComponent:@"Info.plist"]], side * 3);
    if (icon) {
        UIGraphicsImageRenderer *r = [[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(side, side)];
        UIImage *scaled = [r imageWithActions:^(UIGraphicsImageRendererContext *ctx) {
            [icon drawInRect:CGRectMake(0, 0, side, side)];
        }];
        c.imageView.image = scaled;
        c.imageView.layer.cornerRadius = 9;
        c.imageView.clipsToBounds = YES;
    }
    return c;
}

- (void)tableView:(UITableView *)tv didSelectRowAtIndexPath:(NSIndexPath *)ip {
    [tv deselectRowAtIndexPath:ip animated:YES];
    SKInstalledApp *a = self.filtered[ip.row];

    UIAlertController *sheet = [UIAlertController
        alertControllerWithTitle:a.name message:a.bundleID
                  preferredStyle:UIAlertControllerStyleActionSheet];

    __weak typeof(self) weakSelf = self;

    [sheet addAction:[UIAlertAction actionWithTitle:SKLoc(@"apps.menu.bundle")
        style:UIAlertActionStyleDefault handler:^(UIAlertAction *x) {
        [weakSelf browse:a.bundlePath title:@"主程序目录"];
    }]];

    [sheet addAction:[UIAlertAction actionWithTitle:SKLoc(@"apps.menu.group")
        style:UIAlertActionStyleDefault handler:^(UIAlertAction *x) {
        if (a.groupPath) [weakSelf browse:a.groupPath title:@"Group 目录"];
        else [weakSelf toast:SKLoc(@"apps.no.group")];
    }]];

    [sheet addAction:[UIAlertAction actionWithTitle:SKLoc(@"apps.menu.data")
        style:UIAlertActionStyleDefault handler:^(UIAlertAction *x) {
        if (a.dataPath) [weakSelf browse:a.dataPath title:@"数据目录"];
        else [weakSelf toast:SKLoc(@"apps.no.data")];
    }]];

    [sheet addAction:[UIAlertAction actionWithTitle:SKLoc(@"apps.menu.decrypt")
        style:UIAlertActionStyleDefault handler:^(UIAlertAction *x) {
        [weakSelf decryptApp:a];
    }]];

    [sheet addAction:[UIAlertAction actionWithTitle:SKLoc(@"common.cancel") style:UIAlertActionStyleCancel handler:nil]];

    sheet.popoverPresentationController.sourceView = tv;
    sheet.popoverPresentationController.sourceRect = [tv rectForRowAtIndexPath:ip];
    [self presentViewController:sheet animated:YES completion:nil];
}

// ── injected overlay ──────────────────────────────────────────────────────
//
// Every RemoteCall operation runs on `overlayQueue`, a serial background
// queue. A single remote_msg is a Mach round trip through SpringBoard's
// exception ports, so running a few dozen of them on the main thread visibly
// freezes this app — and the panel build is hundreds of them.
//
// The 50 ms timer only *hands work* to that queue and skips a tick while the
// previous one is still running, so a slow SpringBoard can never build up a
// backlog of pending polls.

- (dispatch_queue_t)overlayQueue {
    static dispatch_queue_t q;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        q = dispatch_queue_create("com.blade.overlay", DISPATCH_QUEUE_SERIAL);
    });
    return q;
}

- (void)toggleOverlay {
    SKOverlay *ov = [SKOverlay shared];
    __weak typeof(self) weakSelf = self;

    if (ov.running) {
        [self.overlayTimer invalidate];
        self.overlayTimer = nil;
        SKLog(@"overlay: disable requested");
        dispatch_async(self.overlayQueue, ^{
            [ov stop];
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf toast:@"悬浮球已关闭"];
            });
        });
        return;
    }

    SKLog(@"overlay: enable requested");
    __weak SKOverlay *weakOv = ov;
    dispatch_async(self.overlayQueue, ^{
        NSString *err = [weakOv start];
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(weakSelf) self_ = weakSelf;
            if (!self_) return;
            if (err) { [self_ showDiagnostic:err]; return; }
            [self_ toast:@"悬浮球已开启（在 SpringBoard 上，可拖动）"];
            [self_ startOverlayPolling];
        });
    });
}

- (void)startOverlayPolling {
    if (self.overlayTimer) return;
    __weak typeof(self) weakSelf = self;
    self.overlayTimer = [NSTimer scheduledTimerWithTimeInterval:0.05 repeats:YES block:^(NSTimer *t) {
        __strong typeof(weakSelf) self_ = weakSelf;
        if (!self_) return;
        if (self_.overlayPollBusy) return;          // previous poll still running
        self_.overlayPollBusy = YES;

        dispatch_async(self_.overlayQueue, ^{
            [[SKOverlay shared] pollWithHandler:^(SKOverlayEvent event, NSInteger rowIndex, CGFloat value) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    __strong typeof(weakSelf) self2 = weakSelf;
                    if (!self2) return;
                    if (event == SKOverlayEventBallTapped) {
                        [self2 overlayBallTapped];
                    } else if (event == SKOverlayEventRowTapped) {
                        [self2 overlayRowTapped:rowIndex];
                    }
                });
            }];
            self_.overlayPollBusy = NO;
        });
    }];
}

// Main thread: decide, then hand the remote work to the serial queue.
- (void)overlayBallTapped {
    SKOverlay *ov = [SKOverlay shared];
    if (ov.panelOpen) {
        dispatch_async(self.overlayQueue, ^{
            [ov hidePanel];
            SKLog(@"overlay: panel hidden");
        });
        return;
    }
    [self refreshOverlayProcessList];
}

// Must be called on overlayQueue (it blocks on hundreds of round trips).
- (void)refreshOverlayProcessListLocked {
    double t0 = CFAbsoluteTimeGetCurrent();
    int count = 0;
    proc_entry_t *list = proclist(NULL, &count);
    NSMutableArray *procs = [NSMutableArray array];
    NSMutableArray *labels = [NSMutableArray array];
    if (list && count > 0) {
        for (int i = 0; i < count && i < 100; i++) {
            NSString *name = [NSString stringWithUTF8String:list[i].name] ?: @"";
            [procs addObject:@{ @"pid": @(list[i].pid), @"name": name }];
            [labels addObject:[NSString stringWithFormat:@"%d  %@", list[i].pid, name]];
        }
        free_proclist(list);
    }
    SKLog(@"overlay: proclist returned %d entries, using %lu",
          count, (unsigned long)procs.count);

    self.overlayProcs = procs;
    [[SKOverlay shared] showPanelWithTitle:@"进程" rows:labels];

    double dt = (CFAbsoluteTimeGetCurrent() - t0) * 1000.0;
    SKLog(@"overlay: panel refreshed in %.0fms (%lu rows)", dt, (unsigned long)procs.count);
}

- (void)refreshOverlayProcessList {
    __weak typeof(self) weakSelf = self;
    dispatch_async(self.overlayQueue, ^{
        __strong typeof(weakSelf) self_ = weakSelf;
        if (!self_) return;
        [self_ refreshOverlayProcessListLocked];
    });
}

- (void)overlayRowTapped:(NSInteger)index {
    if (index < 0 || index >= (NSInteger)self.overlayProcs.count) return;
    NSDictionary *p = self.overlayProcs[index];
    SKLog(@"overlay: row %ld tapped -> %@ (pid %@)",
          (long)index, p[@"name"], p[@"pid"]);

    // Stage 1: surface the selection. The in-overlay modifier page is next —
    // it must be drawn inside the overlay, not with a native UIAlertController.
    SKOverlay *ov = [SKOverlay shared];
    dispatch_async(self.overlayQueue, ^{
        [ov showPanelWithTitle:[NSString stringWithFormat:@"%@ (PID %@)", p[@"name"], p[@"pid"]]
                          rows:@[@"读取内存", @"修改内存", @"查看模块", @"返回"]];
    });
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    if (self.overlayTimer) {
        [self.overlayTimer invalidate];
        self.overlayTimer = nil;
    }
}

- (void)browse:(NSString *)path title:(NSString *)title {
    FileManagerViewController *fm = [[FileManagerViewController alloc] initWithPath:path];
    fm.title = title;
    [self.navigationController pushViewController:fm animated:YES];
}

- (void)decryptApp:(SKInstalledApp *)a {
    SKDecryptRunnerViewController *r =
        [[SKDecryptRunnerViewController alloc] initWithAppName:a.name
                                                      bundleID:a.bundleID
                                                    bundlePath:a.bundlePath
                                                    executable:a.executable];
    [self.navigationController pushViewController:r animated:YES];
}

- (void)toast:(NSString *)msg {
    UIAlertController *al = [UIAlertController alertControllerWithTitle:nil message:msg
                                                        preferredStyle:UIAlertControllerStyleAlert];
    [al addAction:[UIAlertAction actionWithTitle:SKLoc(@"common.ok") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:al animated:YES completion:nil];
}

// A UIAlertController silently clips long multi-line messages, which is exactly
// what a diagnosis is. Present it in a full-screen, scrollable, selectable text
// view instead so nothing can be lost.
- (void)showDiagnostic:(NSString *)text {
    UIViewController *vc = [[UIViewController alloc] init];
    vc.view.backgroundColor = UIColor.systemBackgroundColor;
    vc.title = @"悬浮球诊断";

    UITextView *tv = [[UITextView alloc] initWithFrame:vc.view.bounds];
    tv.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    tv.editable = NO;
    tv.selectable = YES;
    tv.font = [UIFont monospacedSystemFontOfSize:12 weight:UIFontWeightRegular];
    tv.text = text;
    tv.textColor = UIColor.labelColor;
    tv.backgroundColor = UIColor.systemBackgroundColor;
    [vc.view addSubview:tv];

    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    nav.modalPresentationStyle = UIModalPresentationFullScreen;
    vc.navigationItem.rightBarButtonItem =
        [[UIBarButtonItem alloc] initWithTitle:SKLoc(@"common.ok")
                                         style:UIBarButtonItemStyleDone
                                        target:self action:@selector(dismissDiagnostic)];
    [self presentViewController:nav animated:YES completion:nil];

    // Also mirror to the log so the host can read it over SSH.
    SKLog(@"=== DIAGNOSTIC ===\n%@\n=== END DIAGNOSTIC ===", text);
}

- (void)dismissDiagnostic {
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end

// ── search ─────────────────────────────────────────────────────────────────
@interface SKAppBrowserViewController (Search) <UISearchBarDelegate>
@end
@implementation SKAppBrowserViewController (Search)
- (void)searchBar:(UISearchBar *)sb textDidChange:(NSString *)text {
    if (!text.length) self.filtered = self.apps;
    else {
        NSPredicate *p = [NSPredicate predicateWithBlock:^BOOL(SKInstalledApp *a, NSDictionary *b) {
            return [a.name localizedCaseInsensitiveContainsString:text] ||
                   [a.bundleID localizedCaseInsensitiveContainsString:text];
        }];
        self.filtered = [self.apps filteredArrayUsingPredicate:p];
    }
    [self.tableView reloadData];
}
@end
