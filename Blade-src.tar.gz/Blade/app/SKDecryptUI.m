//
//  SKDecryptUI.m
//  SandboxKit — 砸壳 (decryption) interface
//
//  Flow (mirrors lara's DecryptView, with the fixes noted):
//
//    1. launch the target so its pages are faulted in and therefore decrypted
//    2. copy the bundle into a scratch dir
//    3. decrypt the main executable into the copy
//    4. decrypt every *encrypted* Mach-O inside the copy — not just
//       Frameworks/*.framework but also PlugIns/*.appex and any nested
//       .framework/.dylib. lara only walked Frameworks/*.framework, so apps
//       shipping an encrypted extension had that extension left encrypted and
//       the installed app misbehaved.
//    5. move into Payload/ and zip to .ipa
//
//  The actual decryption correctness fix (matching the right Mach-O by
//  LC_UUID, and refusing to emit a binary whose pages came back still
//  encrypted) lives in kexploit/decrypt.m.
//

#import "SKDecryptUI.h"
#import "SKLoc.h"
#import "SKZipWriter.h"
#import "decrypt.h"
#import "darksword.h"
#import "SKSandboxKeeper.h"

#include <sys/stat.h>
#include <unistd.h>

static NSString * const kBundleRoot = @"/var/containers/Bundle/Application";

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - Runner (progress + work)
// ─────────────────────────────────────────────────────────────────────────────

@interface SKDecryptRunnerViewController ()
@property (nonatomic, strong) UITextView *log;
@property (nonatomic, copy) NSString *appName, *bundleID, *bundlePath, *executable;
@property (nonatomic, assign) BOOL didLaunchTarget;
- (void)emit:(NSString *)s;
- (void)run;
- (void)finishWithIPA:(NSString *)path error:(NSString *)err;
@end



@implementation SKDecryptRunnerViewController

- (instancetype)initWithAppName:(NSString *)n bundleID:(NSString *)b
                     bundlePath:(NSString *)p executable:(NSString *)e {
    self = [super init];
    if (self) {
        _appName = [n copy]; _bundleID = [b copy];
        _bundlePath = [p copy]; _executable = [e copy];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = self.appName;
    self.view.backgroundColor = UIColor.systemBackgroundColor;

    self.log = [[UITextView alloc] initWithFrame:self.view.bounds];
    self.log.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.log.editable = NO;
    self.log.font = [UIFont monospacedSystemFontOfSize:11 weight:UIFontWeightRegular];
    self.log.textContainerInset = UIEdgeInsetsMake(10, 10, 10, 10);
    [self.view addSubview:self.log];

    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        // Decryption takes a while and we may launch the target app (which
        // backgrounds us). Without a background-task assertion iOS suspends the
        // process mid-decrypt, which looks like a hang or a crash.
        __block UIBackgroundTaskIdentifier bg = UIBackgroundTaskInvalid;
        bg = [[UIApplication sharedApplication]
              beginBackgroundTaskWithName:@"decrypt"
                        expirationHandler:^{
            [[UIApplication sharedApplication] endBackgroundTask:bg];
            bg = UIBackgroundTaskInvalid;
        }];

        // decrypt.m() drives the kernel primitive from C without the Objective-C
        // lock, so pause the keeper for the duration: two concurrent users of
        // the primitive corrupt its state.
        BOOL keeperWasRunning = [SKSandboxKeeper sharedKeeper].running;
        if (keeperWasRunning) [[SKSandboxKeeper sharedKeeper] stop];

        [self run];

        if (keeperWasRunning) [[SKSandboxKeeper sharedKeeper] start];

        if (bg != UIBackgroundTaskInvalid) {
            [[UIApplication sharedApplication] endBackgroundTask:bg];
            bg = UIBackgroundTaskInvalid;
        }
    });
}

- (void)emit:(NSString *)s {
    dispatch_async(dispatch_get_main_queue(), ^{
        self.log.text = [self.log.text stringByAppendingFormat:@"%@\n", s];
        [self.log scrollRangeToVisible:NSMakeRange(self.log.text.length, 0)];
    });
}

- (void)finishWithIPA:(NSString *)path error:(NSString *)err {
    dispatch_async(dispatch_get_main_queue(), ^{
        // Always ask to come back to the front. The target may already have been
        // running (so we never launched it), but decrypting still means the user
        // is looking at another app — or at the home screen after it exited.
        // Re-opening ourselves is a no-op when we are already foreground.
        launch_app(NSBundle.mainBundle.bundleIdentifier.UTF8String);

        if (err) {
            UIAlertController *al = [UIAlertController
                alertControllerWithTitle:SKLoc(@"decrypt.failed.title") message:err
                          preferredStyle:UIAlertControllerStyleAlert];
            [al addAction:[UIAlertAction actionWithTitle:SKLoc(@"common.ok")
                                                   style:UIAlertActionStyleDefault
                                                 handler:^(UIAlertAction *a) {
                [self.navigationController popViewControllerAnimated:YES];
            }]];
            [self presentViewController:al animated:YES completion:nil];
            return;
        }

        // Success: hand the IPA straight to the system share sheet so it can go
        // to Files, AirDrop or another app.
        NSURL *url = [NSURL fileURLWithPath:path];
        UIActivityViewController *av =
            [[UIActivityViewController alloc] initWithActivityItems:@[ url ]
                                             applicationActivities:nil];
        av.popoverPresentationController.sourceView = self.view;
        av.popoverPresentationController.sourceRect = self.view.bounds;
        av.completionWithItemsHandler =
            ^(UIActivityType type, BOOL completed, NSArray *items, NSError *e) {
            [self.navigationController popViewControllerAnimated:YES];
        };
        [self presentViewController:av animated:YES completion:nil];
    });
}

// ── the actual work ────────────────────────────────────────────────────────
- (void)run {
    NSFileManager *fm = NSFileManager.defaultManager;
    NSString *docs = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    NSString *outDir = [docs stringByAppendingPathComponent:@"Decrypted"];
    NSString *workDir = [outDir stringByAppendingPathComponent:
                         [@".tmp_" stringByAppendingString:self.bundleID]];
    NSString *payload = [workDir stringByAppendingPathComponent:@"Payload"];
    NSString *appName = self.bundlePath.lastPathComponent;
    NSString *destApp = [workDir stringByAppendingPathComponent:appName];
    NSString *ipaPath = [[outDir stringByAppendingPathComponent:
                          [self.appName stringByReplacingOccurrencesOfString:@" " withString:@""]]
                         stringByAppendingPathExtension:@"ipa"];

    [fm createDirectoryAtPath:outDir withIntermediateDirectories:YES attributes:nil error:NULL];
    [fm removeItemAtPath:workDir error:NULL];
    [fm createDirectoryAtPath:payload withIntermediateDirectories:YES attributes:nil error:NULL];

    [self emit:[NSString stringWithFormat:SKLoc(@"decrypt.target"), self.appName, self.bundleID]];

    // ── 1. make sure the app is running so its pages are decrypted ────────
    pid_t pid = find_process_pid(self.executable.UTF8String);
    if (pid <= 0) {
        [self emit:SKLoc(@"decrypt.launching")];
        self.didLaunchTarget = YES;
        launch_app(self.bundleID.UTF8String);
        for (int i = 0; i < 40 && pid <= 0; i++) {
            usleep(500 * 1000);
            pid = find_process_pid(self.executable.UTF8String);
        }
    }
    if (pid <= 0) {
        [self emit:SKLoc(@"decrypt.no.process")];
        [self finishWithIPA:nil error:@"目标进程未运行，请先在设备上打开该应用再砸壳"];
        return;
    }
    [self emit:[NSString stringWithFormat:SKLoc(@"decrypt.pid"), pid]];

    set_log_callback(NULL);
    set_progress_callback(NULL);

    // ── 2. copy the bundle ────────────────────────────────────────────────
    [self emit:SKLoc(@"decrypt.copying")];
    NSDirectoryEnumerator *en = [fm enumeratorAtPath:self.bundlePath];
    for (NSString *rel in en) {
        NSString *src = [self.bundlePath stringByAppendingPathComponent:rel];
        NSString *dst = [destApp stringByAppendingPathComponent:rel];
        BOOL isDir = NO;
        if (![fm fileExistsAtPath:src isDirectory:&isDir]) continue;
        if (isDir) [fm createDirectoryAtPath:dst withIntermediateDirectories:YES attributes:nil error:NULL];
        else       [fm copyItemAtPath:src toPath:dst error:NULL];
    }

    // ── 3. decrypt the main executable ────────────────────────────────────
    NSString *srcMain = [self.bundlePath stringByAppendingPathComponent:self.executable];
    NSString *dstMain = [destApp stringByAppendingPathComponent:self.executable];
    [self emit:SKLoc(@"decrypt.main")];
    if (decrypt_binary_pid(srcMain.UTF8String, pid, dstMain.UTF8String) != 0) {
        [self emit:SKLoc(@"decrypt.main.fail")];
        [self finishWithIPA:nil error:@"主二进制解密失败（LC_UUID 未匹配到已加载镜像？）"];
        [fm removeItemAtPath:workDir error:NULL];
        return;
    }
    [self emit:SKLoc(@"decrypt.main.ok")];

    // ── 4. decrypt every other encrypted Mach-O in the copy ───────────────
    // Covers Frameworks/*.framework, PlugIns/*.appex, and any stray .dylib.
    int decrypted = 0, failed = 0;
    NSArray *all = [fm subpathsAtPath:destApp] ?: @[];
    for (NSString *rel in all) {
        @autoreleasepool {
            NSString *full = [destApp stringByAppendingPathComponent:rel];
            BOOL isDir = NO;
            if (![fm fileExistsAtPath:full isDirectory:&isDir] || isDir) continue;

            // Only Mach-O files: match the name used by frameworks / appex /
            // dylibs. Everything else is skipped cheaply.
            NSString *ext = rel.pathExtension.lowercaseString;
            BOOL candidate = [ext isEqualToString:@"dylib"]
                          || [full.pathExtension isEqualToString:@""]  // framework/appex binary
                          || [rel containsString:@".framework/"]
                          || [rel containsString:@".appex/"];
            if (!candidate) continue;
            if ([full isEqualToString:dstMain]) continue;

            if (is_encrypted_path(full.UTF8String) <= 0) continue;

            [self emit:[NSString stringWithFormat:SKLoc(@"decrypt.other"), rel]];
            // Extensions live in their own process, so the host pid will not
            // match their LC_UUID. decrypt_binary_search() falls back to
            // scanning every process for the image.
            if (decrypt_binary_search(full.UTF8String, pid, full.UTF8String) != 0) {
                // Extensions only decrypt while they are actually running; an
                // idle .appex has no process to read from.
                [self emit:[NSString stringWithFormat:@"%@ — 未在运行，无法脱壳（先启动该扩展）", rel]];
                failed++;
            } else {
                decrypted++;
            }
        }
    }
    [self emit:[NSString stringWithFormat:SKLoc(@"decrypt.summary"), decrypted, failed]];

    // ── 5. package ────────────────────────────────────────────────────────
    [self emit:SKLoc(@"decrypt.packaging")];
    NSString *payloadApp = [payload stringByAppendingPathComponent:appName];
    NSError *mvErr = nil;
    if (![fm moveItemAtPath:destApp toPath:payloadApp error:&mvErr]) {
        [self emit:[NSString stringWithFormat:@"[!!] 移动失败: %@", mvErr.localizedDescription]];
        [self finishWithIPA:nil error:mvErr.localizedDescription];
        return;
    }

    // SKZipWriter streams each file straight to disk. The file manager's
    // zipPathTo() buffered the whole bundle in memory, which for a real app
    // meant being jetsam-killed mid-packaging and leaving a zero-byte .ipa.
    __weak typeof(self) weakSelf = self;
    NSString *zipErr = [SKZipWriter zipDirectory:payload
                                          toPath:ipaPath
                                        progress:^(NSString *entry, NSUInteger done, NSUInteger total) {
        // Log sparsely: one line per ~64 entries keeps the console readable.
        if (done % 64 == 0 || done == total) {
            [weakSelf emit:[NSString stringWithFormat:@"  打包 %lu/%lu", (unsigned long)done, (unsigned long)total]];
        }
    }];
    if (zipErr) {
        [self emit:[NSString stringWithFormat:SKLoc(@"decrypt.pack.fail"), zipErr]];
        [self finishWithIPA:nil error:zipErr];
        return;
    }

    // Report the real size so a zero-byte result is obvious in the log.
    NSDictionary *outAttrs = [fm attributesOfItemAtPath:ipaPath error:NULL];
    unsigned long long ipaBytes = [outAttrs[NSFileSize] unsignedLongLongValue];
    if (ipaBytes == 0) {
        [self emit:@"[!!] 打包结果为空"];
        [self finishWithIPA:nil error:@"打包结果为空"];
        return;
    }

    [fm removeItemAtPath:workDir error:NULL];
    [self emit:[NSString stringWithFormat:@"[ok] %@  (%.1f MB)",
                ipaPath, ipaBytes / 1048576.0]];
    [self finishWithIPA:ipaPath error:nil];
}

@end
