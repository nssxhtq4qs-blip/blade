//
//  SKJIT.h
//  Blade
//
//  Enable JIT for a running process.
//
//  HOW THIS DIFFERS FROM THE IMPLEMENTATION IT IS MODELLED ON
//  ---------------------------------------------------------
//  Lara ships two ways to do this, and only one of them is usable.
//
//  The one its UI actually calls runs ptrace(PT_ATTACHEXC) / PT_DETACH inside
//  SpringBoard, through RemoteCall — so it has to hijack SpringBoard's threads
//  and sign return addresses in a process that is not ours. On an A16 that is
//  both fragile and unnecessary, and when it goes wrong the process it takes
//  down is SpringBoard. It also cannot work in principle: ptrace on a process
//  that does not carry get-task-allow is refused, so even a successful
//  hijack reaches a syscall that fails.
//
//  The other one — amfi_patch_proc_csflags() in its amfi.m — is the right
//  idea: set CS_DEBUGGED on the target's AMFI label directly through the
//  kernel. No RemoteCall, no ptrace, no SpringBoard, and no get-task-allow
//  requirement, because nothing is being debugged; the flag that a debugger
//  would have set is simply written.
//
//  This file is that approach, with two deliberate departures:
//
//    * Only CS_DEBUGGED is written. Lara's version also sets CS_PLATFORM_BINARY
//      and CS_GET_TASK_ALLOW and clears CS_HARD | CS_KILL, which together turn
//      the target into something AMFI will no longer kill for a signature
//      violation. None of that is needed for JIT and all of it is a real
//      loosening, so it is left alone.
//
//    * The PAC strip uses XPACD, not XPACI. cr_label and the AMFI label are
//      PACDA-signed DATA pointers, and Lara's own comment records what happens
//      otherwise: XPACI leaves the PACDA tag in place, the address read is
//      wrong, the cs_flags store lands in unrelated memory and the kernel
//      panics. Blade's xpaci.h only carries XPACI, which is why the helper is
//      defined here.
//

#ifndef SKJIT_h
#define SKJIT_h

#import <Foundation/Foundation.h>
#import <sys/types.h>

NS_ASSUME_NONNULL_BEGIN

@interface SKJIT : NSObject

/// Is CS_DEBUGGED already set on this process?
+ (BOOL)isEnabledForPid:(pid_t)pid;

/// Set CS_DEBUGGED on a running process, through the kernel.
///
/// Returns YES when the flag is set and the read-back confirms it. On failure
/// `error` receives a short reason (the resolved addresses are included, since
/// a failure here is almost always a pointer chain that did not validate).
+ (BOOL)enableForPid:(pid_t)pid error:(NSString *_Nullable *_Nullable)error;

/// Human-readable code-signing flags for a process. Read-only.
+ (NSString *)describePid:(pid_t)pid;

@end

NS_ASSUME_NONNULL_END

#endif /* SKJIT_h */
