//
//  SKJIT.m
//  Blade
//

#import "SKJIT.h"

#import "SKLog.h"
#import "SKKernelLock.h"

#import "darksword.h"
#import "offsets.h"
#import "utils.h"

#include <string.h>

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - PAC helpers
// ─────────────────────────────────────────────────────────────────────────────
//
// Blade's xpaci.h carries XPACI only, and XPACI is the wrong instruction here.
//
//   XPACI (0xDAC143E0) strips PAC from an INSTRUCTION pointer (PACIA/PACIB).
//   XPACD (0xDAC147E0) strips PAC from a DATA pointer      (PACDA/PACDB).
//
// cr_label and the AMFI label slot are both PACDA-signed data pointers on A12+.
// Applying XPACI leaves the PACDA tag in place, so the "stripped" value still
// has tag bits in it, the dereference lands somewhere unrelated, and the
// cs_flags store writes into whatever is there. Lara's amfi.m documents this
// exact sequence as a kernel panic it already hit once — which is why this
// duplicates the two helpers rather than reaching for the XPACI that exists.

#define SK_T1SZ       0x19U
#define SK_VA_BITS    (64U - SK_T1SZ)
#define SK_SIGN_BIT   (1ULL << (SK_VA_BITS - 1U))
#define SK_SIGN_MASK  (~((1ULL << SK_VA_BITS) - 1ULL))

static inline uint64_t sk_xpacd(uint64_t ptr) {
    if (ptr == 0) return 0;
    register uint64_t x0 asm("x0") = ptr;
    asm volatile(".long 0xDAC147E0" : "+r"(x0));   // XPACD x0
    return x0;
}

static inline BOOL sk_is_kernel_ptr(uint64_t ptr) {
    if (ptr == 0 || ptr == 0xFFFFFFFFFFFFFFFFULL) return NO;
    return (ptr >> SK_VA_BITS) == ((1ULL << SK_T1SZ) - 1ULL);
}

static inline uint64_t sk_strip_data(uint64_t ptr) {
    if (ptr == 0) return 0;
    if (sk_is_kernel_ptr(ptr)) return ptr;          // already canonical
    uint64_t s = sk_xpacd(ptr);
    return (s & SK_SIGN_BIT) ? (s | SK_SIGN_MASK) : (s & ~SK_SIGN_MASK);
}

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - CS flags
// ─────────────────────────────────────────────────────────────────────────────

#define SK_CS_DEBUGGED         0x10000000u
#define SK_CS_VALID            0x00000001u
#define SK_CS_HARD             0x00000100u
#define SK_CS_KILL             0x00000200u
#define SK_CS_PLATFORM_BINARY  0x04000000u
#define SK_CS_GET_TASK_ALLOW   0x00000004u
#define SK_CS_ADHOC            0x00000800u
#define SK_CS_REQUIRE_LV       0x00002000u
#define SK_CS_RUNTIME          0x00010000u

static NSString *sk_flag_names(uint32_t f) {
    NSMutableArray<NSString *> *n = [NSMutableArray array];
    if (f & SK_CS_VALID)          [n addObject:@"VALID"];
    if (f & SK_CS_HARD)           [n addObject:@"HARD"];
    if (f & SK_CS_KILL)           [n addObject:@"KILL"];
    if (f & SK_CS_GET_TASK_ALLOW) [n addObject:@"GET_TASK_ALLOW"];
    if (f & SK_CS_ADHOC)          [n addObject:@"ADHOC"];
    if (f & SK_CS_REQUIRE_LV)     [n addObject:@"REQUIRE_LV"];
    if (f & SK_CS_RUNTIME)        [n addObject:@"RUNTIME"];
    if (f & SK_CS_PLATFORM_BINARY)[n addObject:@"PLATFORM_BINARY"];
    if (f & SK_CS_DEBUGGED)       [n addObject:@"DEBUGGED"];
    return n.count ? [n componentsJoinedByString:@"|"] : @"none";
}

// proc -> proc_ro -> ucred -> cr_label -> AMFI label.
//
// Every hop is a PAC-signed data pointer and every hop is validated before it
// is dereferenced: a single bad link would otherwise turn a read into a wild
// access. Returns 0 when the chain does not validate, and the caller reports
// rather than writing anywhere.
static uint64_t sk_amfi_label(uint64_t proc, NSMutableString *trace) {
    if (!sk_is_kernel_ptr(proc)) {
        [trace appendFormat:@"proc 0x%llx invalid\n", proc];
        return 0;
    }

    uint64_t proc_ro = sk_strip_data(ds_kread64(proc + off_proc_p_proc_ro));
    if (!sk_is_kernel_ptr(proc_ro)) {
        [trace appendFormat:@"proc_ro 0x%llx invalid\n", proc_ro];
        return 0;
    }

    uint64_t ucred = sk_strip_data(ds_kread64(proc_ro + off_proc_ro_p_ucred));
    if (!sk_is_kernel_ptr(ucred)) {
        [trace appendFormat:@"ucred 0x%llx invalid\n", ucred];
        return 0;
    }

    if (off_ucred_cr_label == 0) {
        [trace appendString:@"off_ucred_cr_label is 0 (offsets not resolved)\n"];
        return 0;
    }
    uint64_t label = sk_strip_data(ds_kread64(ucred + off_ucred_cr_label));
    if (!sk_is_kernel_ptr(label)) {
        [trace appendFormat:@"cr_label 0x%llx invalid\n", label];
        return 0;
    }

    if (off_label_l_perpolicy_amfi == 0) {
        [trace appendString:@"off_label_l_perpolicy_amfi is 0 (offsets not resolved)\n"];
        return 0;
    }
    uint64_t amfi = sk_strip_data(ds_kread64(label + off_label_l_perpolicy_amfi));
    if (!sk_is_kernel_ptr(amfi)) {
        [trace appendFormat:@"amfi label 0x%llx invalid\n", amfi];
        return 0;
    }
    if (amfi & 3) {
        // cs_flags is a uint32 at the base of the label.
        [trace appendFormat:@"amfi label 0x%llx misaligned\n", amfi];
        return 0;
    }

    [trace appendFormat:@"proc=0x%llx proc_ro=0x%llx ucred=0x%llx label=0x%llx amfi=0x%llx",
        proc, proc_ro, ucred, label, amfi];
    return amfi;
}

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - SKJIT
// ─────────────────────────────────────────────────────────────────────────────

@implementation SKJIT

+ (BOOL)isEnabledForPid:(pid_t)pid {
    if (!ds_is_ready() || pid <= 0) return NO;

    uint64_t proc = procbypid(pid);
    if (!proc) return NO;

    NSMutableString *trace = [NSMutableString string];
    [SKKernelLock() lock];
    uint64_t amfi = sk_amfi_label(proc, trace);
    uint32_t flags = amfi ? ds_kread32(amfi) : 0;
    [SKKernelLock() unlock];

    return (flags & SK_CS_DEBUGGED) != 0;
}

+ (BOOL)enableForPid:(pid_t)pid error:(NSString *_Nullable *_Nullable)error {
    if (!ds_is_ready()) {
        if (error) *error = @"kernel R/W is not ready — run the exploit first";
        return NO;
    }
    if (pid <= 0) {
        if (error) *error = @"invalid pid";
        return NO;
    }

    uint64_t proc = procbypid(pid);
    if (!proc) {
        if (error) *error = [NSString stringWithFormat:@"pid %d is not in the process list", pid];
        return NO;
    }

    NSMutableString *trace = [NSMutableString string];
    __block BOOL ok = NO;
    __block uint32_t before = 0, after = 0;

    [SKKernelLock() lock];
    uint64_t amfi = sk_amfi_label(proc, trace);
    if (amfi) {
        before = ds_kread32(amfi);

        // ONLY CS_DEBUGGED. This is the flag a debugger attach would set, and it
        // is the whole of what turns JIT on — every on-device JIT enabler works
        // by getting a debugger attached for exactly this reason.
        //
        // Deliberately NOT done, although the implementation this is modelled on
        // does all of them:
        //   CS_PLATFORM_BINARY   makes the process count as a platform binary
        //   CS_GET_TASK_ALLOW    lets any task_for_pid succeed against it
        //   clearing CS_HARD|CS_KILL  stops AMFI killing it on a signature fault
        // None are required for JIT and each one is a real loosening.
        after = before | SK_CS_DEBUGGED;
        ds_kwrite32(amfi, after);
        ok = (ds_kread32(amfi) == after);
    }
    [SKKernelLock() unlock];

    SKLog(@"[jit] pid=%d %@ flags 0x%08x (%@) -> 0x%08x (%@) — %@",
          pid, ok ? @"OK" : @"FAILED", before, sk_flag_names(before),
          after, sk_flag_names(after), trace);

    if (ok) return YES;

    if (error) {
        if (amfi == 0) {
            *error = [NSString stringWithFormat:
                @"could not resolve the AMFI label.\n\n%@", trace];
        } else {
            *error = [NSString stringWithFormat:
                @"the write did not land: wrote 0x%08x, read back 0x%08x.\n\n%@",
                after, ds_kread32(amfi), trace];
        }
    }
    return NO;
}

+ (NSString *)describePid:(pid_t)pid {
    if (!ds_is_ready()) return @"kernel R/W not ready";
    uint64_t proc = procbypid(pid);
    if (!proc) return [NSString stringWithFormat:@"pid %d not found", pid];

    NSMutableString *trace = [NSMutableString string];
    [SKKernelLock() lock];
    uint64_t amfi = sk_amfi_label(proc, trace);
    uint32_t flags = amfi ? ds_kread32(amfi) : 0;
    [SKKernelLock() unlock];

    if (!amfi) return [NSString stringWithFormat:@"label chain failed: %@", trace];

    return [NSString stringWithFormat:@"cs_flags = 0x%08x (%@)",
            flags, sk_flag_names(flags)];
}

@end
