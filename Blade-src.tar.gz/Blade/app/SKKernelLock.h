//
//  SKKernelLock.h
//  Blade — serialise access to the kernel primitives
//
//  The exploit's read/write helpers and kexploit's vm layer are NOT thread
//  safe: vmmapremotepage() allocates a memory entry, repurposes a vm_map entry
//  and bumps the target vm_object's refcount through the kernel, and the
//  kread/kwrite primitives share per-process state. Two threads doing that at
//  once corrupts that state — which surfaces as a kernel panic.
//
//  Anything in this app that touches the primitive must hold this lock for the
//  duration of the operation.
//

#ifndef SK_KERNEL_LOCK_H
#define SK_KERNEL_LOCK_H

#import <Foundation/Foundation.h>

/// Process-wide lock guarding the kernel R/W primitives.
static inline NSLock *SKKernelLock(void) {
    static NSLock *lock;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ lock = [[NSLock alloc] init]; });
    return lock;
}

#endif
