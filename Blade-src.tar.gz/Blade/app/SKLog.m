//
//  SKLog.m
//  Blade
//

#import "SKLog.h"
#import "SKDiag.h"
#import "darksword.h"

#include <stdarg.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

// Keep the file bounded; the interesting part is always the tail.
static const long long kSKLogMaxBytes = 256 * 1024;

static FILE *gSKLogFile = NULL;
static FILE *gSKMirrorFile = NULL;      // live copy in the Fliza shared folder
static time_t gSKLastMirrorTry = 0;
static NSLock *gSKLogLock = nil;

static FILE *sk_open(const char *path) {
    struct stat st;
    if (stat(path, &st) == 0 && st.st_size > kSKLogMaxBytes) {
        unlink(path);                   // start clean once it gets big
    }
    FILE *f = fopen(path, "a");
    if (f) setvbuf(f, NULL, _IOLBF, 0);
    return f;
}

static void sk_log_open(void) {
    NSString *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,
                                                         NSUserDomainMask, YES).firstObject;
    if (docs.length) {
        NSString *path = [docs stringByAppendingPathComponent:@"sk.log"];
        gSKLogFile = sk_open(path.fileSystemRepresentation);
    }
    // The mirror into the shared folder is NOT opened here on purpose. It used
    // to be, which meant every launch enumerated a container directory the app
    // has no business touching before the sandbox escape is applied. It is now
    // opened lazily, and only once the kernel primitive is up (see SKLog()).
}

NSString *SKLogPath(void) {
    NSString *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,
                                                         NSUserDomainMask, YES).firstObject;
    return docs.length ? [docs stringByAppendingPathComponent:@"sk.log"] : @"(no Documents)";
}

void SKLog(NSString *fmt, ...) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        gSKLogLock = [[NSLock alloc] init];
        sk_log_open();
    });

    if (!gSKLogFile && !gSKMirrorFile) return;

    va_list ap;
    va_start(ap, fmt);
    NSString *msg = [[NSString alloc] initWithFormat:fmt arguments:ap];
    va_end(ap);

    // Fixed-format timestamp: avoids NSDateFormatter cost on every line.
    struct timeval tv;
    gettimeofday(&tv, NULL);
    struct tm tmv;
    time_t secs = tv.tv_sec;
    localtime_r(&secs, &tmv);

    [gSKLogLock lock];
    char line[4096];
    snprintf(line, sizeof(line), "%02d:%02d:%02d.%03d  %s\n",
             tmv.tm_hour, tmv.tm_min, tmv.tm_sec, (int)(tv.tv_usec / 1000),
             msg.UTF8String ?: "");
    if (gSKLogFile)   { fputs(line, gSKLogFile);   fflush(gSKLogFile); }
    if (gSKMirrorFile) {
        fputs(line, gSKMirrorFile);
        fflush(gSKMirrorFile);
    } else if (gSKLastMirrorTry != tv.tv_sec && ds_is_ready()) {
        // Only after the kernel primitive is up: that implies the sandbox
        // escape has been applied, so the shared folder is actually reachable.
        // Retry at most once a second.
        gSKLastMirrorTry = tv.tv_sec;
        NSString *shared = SKSharedDir();
        if (shared.length) {
            gSKMirrorFile = sk_open([[shared stringByAppendingPathComponent:@"blade-live.log"]
                                        fileSystemRepresentation]);
        }
    }
    [gSKLogLock unlock];
}
