//
//  main.m
//  Blade — iOS kernel toolbox
//
//  Terminal-style main screen.
//
//    idle     banner · {!} not running · {!} run exploit        (centre blank)
//    running  banner · {!} running     · {!} run exploit <spin>
//             + a scrolling log beneath, with a Dopamine-style animated prefix
//    done     banner + progress bar · {✓} rows · {} menu rows
//
//  All text is monospaced, all strings are localised, and no colour scheme is
//  forced — the system appearance and language are followed.
//

#import <UIKit/UIKit.h>
#import "Exploit.h"
#import "FileManager.h"
#import "ProcessListViewController.h"
#import "SKDecryptUI.h"
#import "SKAppBrowser.h"
#import "SKSandboxKeeper.h"
#import "SKLoc.h"
#import "SKLog.h"
#import "SKDiag.h"
#import "SKKernelLock.h"
#import "darksword.h"
#import "offsets.h"

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - Palette / fonts
// ─────────────────────────────────────────────────────────────────────────────

static UIColor *TuiText(void)  { return UIColor.labelColor; }
static UIColor *TuiDim(void)   { return UIColor.secondaryLabelColor; }
static UIColor *TuiGreen(void) { return UIColor.systemGreenColor; }
static UIColor *TuiRed(void)   { return UIColor.systemRedColor; }
static UIColor *TuiOrange(void){ return UIColor.systemOrangeColor; }

// ANSI-shadow style banner. 42 columns x 6 rows of box drawing, no emoji.
static NSString *BladeBanner(void) {
    return @"██████╗ ██╗      █████╗ ██████╗ ███████╗\n"
            "██╔══██╗██║     ██╔══██╗██╔══██╗██╔════╝\n"
            "██████╔╝██║     ███████║██║  ██║█████╗  \n"
            "██╔══██╗██║     ██╔══██║██║  ██║██╔══╝  \n"
            "██████╔╝███████╗██║  ██║██████╔╝███████╗\n"
            "╚═════╝ ╚══════╝╚═╝  ╚═╝╚═════╝ ╚══════╝";
}

// Spinner frames, cycled one per tick.
static NSArray<NSString *> *SpinFrames(void) {
    return @[ @"|", @"/", @"—", @"\\" ];
}

// Six-cell text progress bar.
static NSString *ProgressBar(int filled, int total) {
    NSMutableString *s = [NSMutableString string];
    for (int i = 0; i < total; i++) [s appendString:(i < filled ? @"█" : @"░")];
    return s;
}

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - Tappable TUI line
// ─────────────────────────────────────────────────────────────────────────────

@interface TuiLine : UIControl
@property (nonatomic, strong) UILabel *label;
@property (nonatomic, copy) void (^action)(void);
- (instancetype)initWithText:(NSString *)text color:(UIColor *)color action:(void (^)(void))action;
@end

@implementation TuiLine

- (instancetype)initWithText:(NSString *)text color:(UIColor *)color action:(void (^)(void))action {
    self = [super initWithFrame:CGRectZero];
    if (self) {
        _action = [action copy];
        _label = [[UILabel alloc] initWithFrame:CGRectZero];
        _label.text = text;
        _label.font = SKMono(14, UIFontWeightMedium);
        _label.textColor = color;
        _label.numberOfLines = 1;
        [self addSubview:_label];
        if (action) {
            [self addTarget:self action:@selector(tapped) forControlEvents:UIControlEventTouchUpInside];
            [self addTarget:self action:@selector(down) forControlEvents:UIControlEventTouchDown];
            [self addTarget:self action:@selector(up) forControlEvents:
                UIControlEventTouchUpInside | UIControlEventTouchUpOutside | UIControlEventTouchCancel];
        }
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.label.frame = self.bounds;
}

- (void)tapped { if (self.enabled && self.action) self.action(); }
- (void)down   { if (self.enabled) self.label.alpha = 0.5; }
- (void)up     { self.label.alpha = self.enabled ? 1.0 : 0.35; }

- (void)setEnabled:(BOOL)enabled {
    [super setEnabled:enabled];
    self.label.alpha = enabled ? 1.0 : 0.35;
}

- (void)setText:(NSString *)t { self.label.text = t; }
- (NSString *)text { return self.label.text; }

@end

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - Main
// ─────────────────────────────────────────────────────────────────────────────

typedef NS_ENUM(NSInteger, BladeState) { BladeStateIdle, BladeStateRunning, BladeStateReady };

@interface MainViewController : UIViewController
@property (nonatomic, assign) BladeState state;

@property (nonatomic, strong) UILabel *banner;

@property (nonatomic, strong) TuiLine *statusRunning;
@property (nonatomic, strong) TuiLine *lineRun;

@property (nonatomic, strong) UITextView *logView;
@property (nonatomic, strong) NSMutableArray<NSString *> *logLines;

@property (nonatomic, strong) UIView *menuBox;
@property (nonatomic, strong) NSMutableArray<TuiLine *> *menuLines;

@property (nonatomic, strong) NSTimer *spinTimer;
@property (nonatomic, assign) NSInteger spinFrame;

@property (nonatomic, strong) NSMutableArray<void (^)(void)> *pendingSteps;
@property (nonatomic, assign) NSInteger stepsDone;
@property (nonatomic, assign) NSInteger stepsTotal;

// Kernelcache prefetch runs once per launch.
@property (nonatomic, assign) BOOL kernelcachePrefetched;

// YES only once a kernelcache is present AND parsed. The exploit is gated on
// this: running ds_run() without resolved offsets is what panics the kernel.
@property (nonatomic, assign) BOOL kernelcacheReady;
@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.systemBackgroundColor;
    self.logLines = [NSMutableArray array];
    self.menuLines = [NSMutableArray array];

    __weak typeof(self) weakSelf = self;
    [SKSandboxKeeper sharedKeeper].onEvent = ^(NSString *msg) {
        [weakSelf appendLog:msg];
    };

    [self buildBanner];
    [self buildStatus];
    [self buildLog];
    [self buildMenu];
    [self applyState:BladeStateIdle];

    // Get the kernelcache in place as soon as the app opens, the way Lara does
    // it. Without it offsets_init() has no symbols to resolve and "Run Exploit"
    // fails with "Cannot find our process", which is a confusing thing to hit
    // after a fresh install (a new container means Documents/kernelcache is
    // gone).
    // NOTE: persistence is NOT done by stashing the primitive into launchd.
    // darksword has that mechanism (transfer_krw_to_launchd / recover_krw_
    // primitives) gated on NSUserDefaults[@"stashKRW"], but turning it on makes
    // ds_run() panic immediately: launchd runs as uid 0 and a uid-501 process
    // cannot legitimately touch it, so that path dies before RemoteCall is even
    // attempted.
    //
    // Persistence is instead the periodic sandbox-policy repair in
    // SKSandboxKeeper — re-apply the policy edit with the kernel R/W primitive
    // we already hold. Never re-run the exploit chain.
    [self prefetchKernelcache];

    // Backgrounding loses the sandbox policy edit (the kernel re-derives it) and
    // leaves the kernel primitive in a state we have not characterised. Stop all
    // kernel writes while we are in the background, and say plainly on return
    // whether write access survived — the memory tools then know to expect a loss
    // instead of hammering the primitive.
    [NSNotificationCenter.defaultCenter addObserver:self
                                           selector:@selector(appDidEnterBackground)
                                               name:UIApplicationDidEnterBackgroundNotification
                                             object:nil];
    [NSNotificationCenter.defaultCenter addObserver:self
                                           selector:@selector(appWillEnterForeground)
                                               name:UIApplicationWillEnterForegroundNotification
                                             object:nil];
}

- (void)appDidEnterBackground {
    // No kernel writes from the background: the policy edit is gone by the time
    // we come back anyway, and a re-apply from here has no way to report it.
    [[SKSandboxKeeper sharedKeeper] stop];
    SKLog(@"lifecycle: entered background — keeper stopped, no kernel writes");
}

- (void)appWillEnterForeground {
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        BOOL writeAccess = [SKSandboxKeeper hasPrivilegedWriteAccess];
        SKLog(@"lifecycle: foreground — privileged write access = %@", writeAccess ? @"yes" : @"NO");
        [self appendLog:writeAccess
            ? @"[*] 回到前台：写权限仍在"
            : @"[!] 回到前台：写/删权限已丢失 —— 请重新运行 exploit 再用内存功能"];

        if (writeAccess) {
            [[SKSandboxKeeper sharedKeeper] start];
        }
    });
}

// ── kernelcache prefetch ───────────────────────────────────────────────────
//
// Order matters here, and it is deliberately different from a plain
// "dlkcache() and hope":
//
//   1. Does Documents/kernelcache already exist and look valid?
//        YES -> parse it and stop. No download, no permission work, nothing
//               that touches anything outside our own container. This is the
//               common case after the first successful fetch, and it is the
//               only path that is allowed to leave the exploit armed.
//        NO  -> fetch one (libgrabkernel2, i.e. Lara's "Fetch Kernelcache")
//               and LEAVE THE EXPLOIT DISARMED. Running ds_run() with no
//               resolved offsets is what turns into a panic, so it is not
//               offered until a kernelcache is actually present.
//
// Neither offsets_init() nor the parse path touches the kernel primitive, so
// all of this is safe to run before ds_run().
- (void)prefetchKernelcache {
    if (self.kernelcachePrefetched) return;
    self.kernelcachePrefetched = YES;

    [self appendLog:@"[*] 启动：检查内核缓存…"];
    [self fetchKernelcacheIfNeeded];
}

// Obtain a usable kernelcache, checking for an existing one first.
//
//   1. Documents/kernelcache already present and valid?
//        YES -> parse it and stop. No download, no permission work, nothing
//               outside our own container.
//        NO  -> fetch one (libgrabkernel2, i.e. Lara's "Fetch Kernelcache").
//
// kernelcacheReady is only set when offsets are actually resolved. The exploit
// is gated on that flag, because ds_run() with no resolved offsets panics.
- (void)fetchKernelcacheIfNeeded {
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        offsets_init();                       // CPU-family offsets, no KRW needed

        if (kernelcache_present()) {
            [self appendLog:@"[✓] 内核缓存已存在 —— 直接解析（不下载、不申请权限）"];
            BOOL ok = kernelcache_parse();
            self.kernelcacheReady = ok;
            [self appendLog:ok ? @"[✓] 内核偏移已解析，可以运行 exploit"
                              : @"[!] 内核缓存解析失败 —— exploit 保持禁用（避免 panic）"];
            [self refreshRunAvailability];
            return;
        }

        [self appendLog:@"[!] 内核缓存不存在 —— 正在获取（此期间不运行 exploit）"];
        BOOL got = dlkcache();
        self.kernelcacheReady = got;
        [self appendLog:got ? @"[✓] 内核缓存获取成功，可以运行 exploit"
                            : @"[!] 获取失败 —— exploit 保持禁用（避免 panic）"];
        [self refreshRunAvailability];
    });
}

// Reflect kernelcache availability in the UI so it is obvious whether the
// exploit is armed.
- (void)refreshRunAvailability {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self renderLog];
    });
}

// ── construction ───────────────────────────────────────────────────────────
- (UILabel *)monoLabel:(CGFloat)size weight:(UIFontWeight)w {
    UILabel *l = [[UILabel alloc] init];
    l.font = SKMono(size, w);
    l.textColor = TuiText();
    l.numberOfLines = 1;
    return l;
}

- (void)buildBanner {
    self.banner = [[UILabel alloc] init];
    self.banner.text = BladeBanner();
    self.banner.font = SKMono(13, UIFontWeightBold);
    self.banner.textColor = TuiText();
    self.banner.numberOfLines = 6;
    self.banner.adjustsFontSizeToFitWidth = YES;
    self.banner.minimumScaleFactor = 0.4;
    self.banner.lineBreakMode = NSLineBreakByClipping;
    [self.view addSubview:self.banner];

}

- (void)buildStatus {
    self.statusRunning = [[TuiLine alloc] initWithText:@"{!} " color:TuiDim() action:nil];
    [self.view addSubview:self.statusRunning];

    __weak typeof(self) weakSelf = self;
    self.lineRun = [[TuiLine alloc] initWithText:@"{!} " color:TuiText() action:^{
        [weakSelf startRun];
    }];
    [self.view addSubview:self.lineRun];
}

- (void)buildLog {
    self.logView = [[UITextView alloc] init];
    self.logView.backgroundColor = UIColor.clearColor;
    self.logView.editable = NO;
    self.logView.selectable = NO;
    self.logView.scrollEnabled = YES;
    self.logView.textContainerInset = UIEdgeInsetsZero;
    self.logView.textContainer.lineFragmentPadding = 0;
    self.logView.font = SKMono(11, UIFontWeightRegular);
    self.logView.textColor = TuiDim();
    self.logView.hidden = YES;
    [self.view addSubview:self.logView];
}

- (void)buildMenu {
    self.menuBox = [[UIView alloc] init];
    self.menuBox.hidden = YES;
    [self.view addSubview:self.menuBox];

    __weak typeof(self) weakSelf = self;
    NSArray *defs = @[
        @[ @"tui.menu.apps",  @"apps" ],
        @[ @"tui.menu.files", @"files" ],
        @[ @"tui.menu.procs", @"procs" ],
        @[ @"tui.menu.repair", @"repair" ],
        @[ @"tui.menu.panic", @"panic" ],
    ];
    for (NSArray *d in defs) {
        NSString *key = d[0], *kind = d[1];
        UIColor *col = [kind isEqualToString:@"panic"] ? TuiRed() : TuiText();
        TuiLine *l = [[TuiLine alloc] initWithText:[NSString stringWithFormat:@"{} %@", SKLoc(key)]
                                             color:col
                                            action:^{ [weakSelf menuTap:kind]; }];
        [self.menuBox addSubview:l];
        [self.menuLines addObject:l];
    }
}

// ── layout ─────────────────────────────────────────────────────────────────
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    CGFloat w = self.view.bounds.size.width, h = self.view.bounds.size.height;
    CGFloat top = self.view.safeAreaInsets.top, bot = self.view.safeAreaInsets.bottom;
    CGFloat x = 16, cw = w - 32;

    self.banner.frame = CGRectMake(x, top + 12, cw, 96);

    CGFloat y = top + 118;
    self.statusRunning.frame = CGRectMake(x, y, cw, 22); y += 24;
    self.lineRun.frame = CGRectMake(x, y, cw, 22);       y += 30;

    CGFloat logH = h - y - bot - 16;
    if (logH < 0) logH = 0;
    self.logView.frame = CGRectMake(x, y, cw, logH);

    self.menuBox.frame = CGRectMake(x, y, cw, MIN(self.menuLines.count * 26.0, logH));
    CGFloat my = 0;
    for (TuiLine *l in self.menuLines) {
        l.frame = CGRectMake(0, my, cw, 24);
        my += 26;
    }
}

// ── state ──────────────────────────────────────────────────────────────────
- (void)applyState:(BladeState)state {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self applyState:state]; });
        return;
    }
    self.state = state;
    BOOL idle = (state == BladeStateIdle);
    BOOL running = (state == BladeStateRunning);
    BOOL ready = (state == BladeStateReady);

    self.logView.hidden = !running;
    self.menuBox.hidden = !ready;

    // Status line marker reflects state.
    NSString *prefix = ready ? @"{✓}" : @"{!}";
    NSString *stateText = SKLoc((ready || running) ? @"tui.status.running" : @"tui.status.idle");
    // The completion bar lives inline on the status line. As a separate label it
    // overlapped the last rows of the banner and looked like a stray green block.
    NSString *suffix = ready ? [@"  " stringByAppendingString:ProgressBar(6, 6)] : @"";
    self.statusRunning.text = [NSString stringWithFormat:@"%@ %@%@", prefix, stateText, suffix];
    self.statusRunning.label.textColor = ready ? TuiGreen() : (running ? TuiOrange() : TuiDim());

    if (ready) {
        self.lineRun.text = [NSString stringWithFormat:@"{✓} %@", SKLoc(@"tui.action.run")];
        self.lineRun.label.textColor = TuiGreen();
        [self.lineRun setEnabled:NO];
    } else if (running) {
        // The spinner timer keeps this frame up to date; seed it with the
        // current frame so the row never renders an empty suffix.
        self.lineRun.text = [NSString stringWithFormat:@"{!} %@ %@",
                             SKLoc(@"tui.action.run"), SpinFrames()[self.spinFrame]];
        self.lineRun.label.textColor = TuiText();
        [self.lineRun setEnabled:NO];
    } else {
        self.lineRun.text = [NSString stringWithFormat:@"{!} %@", SKLoc(@"tui.action.run")];
        self.lineRun.label.textColor = TuiText();
        [self.lineRun setEnabled:YES];
    }

    [self.view setNeedsLayout];
}

// ── log ────────────────────────────────────────────────────────────────────
// UI updates must happen on the main thread. The bring-up routine runs on a
// background queue and logs from there, so marshal here rather than at every
// call site — touching a UITextView off the main thread is undefined behaviour
// and crashes.
- (void)appendLog:(NSString *)line {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self appendLog:line]; });
        return;
    }
    // Completed lines settle to a static marker; the newest line is the one the
    // spinner animates, which is the Dopamine-style effect.
    [self.logLines addObject:line];
    if (self.logLines.count > 400) [self.logLines removeObjectAtIndex:0];
    [self renderLog];
}

- (void)renderLog {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self renderLog]; });
        return;
    }
    NSMutableString *s = [NSMutableString string];
    NSUInteger n = self.logLines.count;
    for (NSUInteger i = 0; i < n; i++) {
        BOOL last = (i + 1 == n);
        NSString *mark = last ? SpinFrames()[self.spinFrame] : @"·";
        if (self.state == BladeStateReady) mark = @"·";
        [s appendFormat:@"%@ %@\n", mark, self.logLines[i]];
    }
    self.logView.text = s;
    if (s.length) [self.logView scrollRangeToVisible:NSMakeRange(s.length, 0)];
}

// ── run ────────────────────────────────────────────────────────────────────
- (void)startRun {
    if (self.state != BladeStateIdle) return;

    // ── gate: never run the exploit without a parsed kernelcache ────────────
    // ds_run() with unresolved offsets is exactly what produces a kernel panic,
    // so it is simply not offered in that state. Fetching is allowed; running is
    // not, until one is present.
    if (!self.kernelcacheReady) {
        [self.logLines removeAllObjects];
        [self appendLog:@"[!] 内核缓存不存在 —— 已阻止运行 exploit（避免 panic）"];
        [self appendLog:@"[!] 没有内核偏移就调用 ds_run() 会直接打崩内核"];
        [self appendLog:@"[*] 正在获取内核缓存，完成后可再次点击"];
        [self renderLog];
        [self fetchKernelcacheIfNeeded];
        return;
    }

    [self.logLines removeAllObjects];
    self.stepsDone = 0;
    self.stepsTotal = 8;
    [self applyState:BladeStateRunning];
    [self startSpinner];

    __weak typeof(self) weakSelf = self;

    // Steps that are logged around the vendor bring-up routine. Each entry is
    // emitted immediately before the work it describes, so a hang or failure
    // leaves the last line visible.
    void (^step)(NSString *) = ^(NSString *key) {
        __strong typeof(weakSelf) self_ = weakSelf;
        if (!self_) return;
        self_.stepsDone++;
        [self_ appendLog:[NSString stringWithFormat:@"(%ld/%ld) %@",
                          (long)self_.stepsDone, (long)self_.stepsTotal, SKLoc(key)]];
    };

    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        __strong typeof(weakSelf) self_ = weakSelf;
        if (!self_) return;

        step(@"tui.log.offsets");
        step(@"tui.log.kernelcache");
        step(@"tui.log.darksword");

        BOOL ok = [ExploitHelper runExploitWithLog:^(NSString *line) {
            // Vendor lines are forwarded verbatim, prefixed so they are
            // distinguishable from our own step lines.
            if (line.length) [self_ appendLog:[NSString stringWithFormat:@"  %@", line]];
        }];

        if (ok) {
            step(@"tui.log.sandbox");

            dispatch_async(dispatch_get_main_queue(), ^{
                [self_ appendLog:[NSString stringWithFormat:SKLoc(@"tui.log.kbase"),
                                  (unsigned long long)ds_get_kernel_base()]];
                [self_ appendLog:[NSString stringWithFormat:SKLoc(@"tui.log.kslide"),
                                  (unsigned long long)ds_get_kernel_slide()]];
                [self_ appendLog:[NSString stringWithFormat:SKLoc(@"tui.log.proc"),
                                  (unsigned long long)ds_get_our_proc()]];
                [self_ appendLog:[NSString stringWithFormat:SKLoc(@"tui.log.task"),
                                  (unsigned long long)ds_get_our_task()]];
                step(@"tui.log.vfs");
                step(@"tui.log.keeper");
                step(@"tui.log.done");

                [[SKSandboxKeeper sharedKeeper] start];

                // The sandbox escape is in place now, so this can reach the
                // crash reporter and the Fliza shared folder. Runs off the
                // main thread: it walks directories over the filesystem.
                dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
                    NSString *rep = SKDumpToShared();
                    NSLog(@"[blade] diag:\n%@", rep);
                });

                // Hide the log shortly after success and reveal the menu.
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.7 * NSEC_PER_SEC)),
                               dispatch_get_main_queue(), ^{
                    [self_ stopSpinner];
                    [self_ applyState:BladeStateReady];
                });
            });
        } else {
            NSString *err = [ExploitHelper errorMessage] ?: @"";
            dispatch_async(dispatch_get_main_queue(), ^{
                [self_ appendLog:[NSString stringWithFormat:SKLoc(@"tui.log.fail"), err]];
                [self_ stopSpinner];
                [self_ applyState:BladeStateIdle];   // back to a re-runnable state
                [self_ appendLog:@""];
            });
        }
    });
}

// ── spinner ────────────────────────────────────────────────────────────────
- (void)startSpinner {
    self.spinFrame = 0;
    __weak typeof(self) weakSelf = self;
    self.spinTimer = [NSTimer scheduledTimerWithTimeInterval:0.12 repeats:YES block:^(NSTimer *t) {
        __strong typeof(weakSelf) self_ = weakSelf;
        if (!self_ || self_.state != BladeStateRunning) return;
        self_.spinFrame = (self_.spinFrame + 1) % (NSInteger)SpinFrames().count;
        self_.lineRun.text = [NSString stringWithFormat:@"{!} %@ %@",
                              SKLoc(@"tui.action.run"), SpinFrames()[self_.spinFrame]];
        [self_ renderLog];
    }];
}

- (void)stopSpinner {
    [self.spinTimer invalidate];
    self.spinTimer = nil;
}

- (void)dealloc { [self stopSpinner]; }

// ── menu ───────────────────────────────────────────────────────────────────
- (void)menuTap:(NSString *)kind {
    if ([kind isEqualToString:@"apps"]) {
        [self presentInNav:[[SKAppBrowserViewController alloc] init]];
    } else if ([kind isEqualToString:@"files"]) {
        FileManagerViewController *fm = [[FileManagerViewController alloc] initWithPath:@"/var"];
        fm.title = SKLoc(@"tui.menu.files");
        [self presentInNav:fm];
    } else if ([kind isEqualToString:@"procs"]) {
        [self presentInNav:[[ProcessListViewController alloc] init]];
    } else if ([kind isEqualToString:@"repair"]) {
        [self repairWriteAccess];
    } else if ([kind isEqualToString:@"panic"]) {
        [self confirmPanic];
    }
}

// ── repair write access ────────────────────────────────────────────────────
//
// The sandbox policy edit is volatile — the kernel re-derives it and write
// access silently disappears. Re-running the exploit restores it; so does
// re-applying just the policy edit, which is one memory write with none of the
// re-exploitation risk. That is what this does, and it says what happened.
- (void)repairWriteAccess {
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        if (!ds_is_ready()) {
            [self appendLog:@"repair: ds_is_ready=0 — exploit not running"];
            return;
        }
        BOOL before = [SKSandboxKeeper hasPrivilegedWriteAccess];
        BOOL after  = [SKSandboxKeeper ensureWriteAccess];
        [self appendLog:[NSString stringWithFormat:
            @"repair: probe before=%d after=%d", before ? 1 : 0, after ? 1 : 0]];
    });
}

- (void)confirmPanic {
    UIAlertController *al = [UIAlertController
        alertControllerWithTitle:SKLoc(@"tui.panic.title")
                         message:SKLoc(@"tui.panic.body")
                  preferredStyle:UIAlertControllerStyleAlert];

    [al addAction:[UIAlertAction actionWithTitle:SKLoc(@"common.cancel")
                                           style:UIAlertActionStyleCancel handler:nil]];
    [al addAction:[UIAlertAction actionWithTitle:SKLoc(@"tui.panic.confirm")
                                           style:UIAlertActionStyleDestructive
                                         handler:^(UIAlertAction *a) { [self doPanic]; }]];
    [self presentViewController:al animated:YES completion:nil];
}

- (void)doPanic {
    // Corrupt this process's linkage in the kernel's allproc list. The next
    // walk (which the scheduler performs constantly) dereferences the bogus
    // pointer and the kernel panics. Nothing here is recoverable by design —
    // that is the point of the button.
    if (!ds_is_ready()) return;
    uint64_t proc = ds_get_our_proc();
    if (!proc) return;

    [self appendLog:SKLoc(@"tui.panic.done")];
    // Take the kernel lock so this cannot interleave with SKSandboxKeeper's
    // sbx_escape() re-apply. Both mutate kernel memory and a torn write would
    // corrupt something other than the two fields we mean to corrupt.
    [SKKernelLock() lock];
    ds_kwrite64(proc + off_proc_p_list_le_next, 0x4141414141414141ULL);
    ds_kwrite64(proc + off_proc_p_list_le_prev, 0x4141414141414141ULL);
    [SKKernelLock() unlock];
}

// ── navigation ─────────────────────────────────────────────────────────────
- (void)presentInNav:(UIViewController *)root {
    root.navigationItem.leftBarButtonItem =
        [[UIBarButtonItem alloc] initWithTitle:SKLoc(@"common.close")
                                        style:UIBarButtonItemStylePlain
                                       target:self action:@selector(closeModal)];
    UINavigationController *nc = [[UINavigationController alloc] initWithRootViewController:root];
    nc.modalPresentationStyle = UIModalPresentationFullScreen;
    nc.navigationBar.tintColor = TuiText();
    [self presentViewController:nc animated:YES completion:nil];
}

- (void)closeModal { [self dismissViewControllerAnimated:YES completion:nil]; }

@end

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - App delegate
// ─────────────────────────────────────────────────────────────────────────────

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic, strong) UIWindow *window;
@end

@implementation AppDelegate
- (BOOL)application:(UIApplication *)application
        didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = UIColor.systemBackgroundColor;
    self.window.rootViewController = [[MainViewController alloc] init];
    [self.window makeKeyAndVisible];
    SKLog(@"=== blade launched: %@ / %@ ===",
          NSBundle.mainBundle.infoDictionary[@"CFBundleShortVersionString"] ?: @"?",
          NSBundle.mainBundle.bundleIdentifier ?: @"?");
    SKLog(@"log file: %@", SKLogPath());
    return YES;
}
@end

int main(int argc, char *argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
